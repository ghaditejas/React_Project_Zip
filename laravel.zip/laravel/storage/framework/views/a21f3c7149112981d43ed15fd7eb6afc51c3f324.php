<?php ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Index Page</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('js/datatables/dataTables.bootstrap.css')); ?>">

    </head>
    <body>
        <div class="container">
            <h1>Products</h1>
            <a href="<?php echo e(action('ProductController@create')); ?>" class="btn btn-success" style="float: right;">ADD</a>
            <a href="<?php echo e(action('CategoryController@index')); ?>" class="btn btn-success" style="float: right;">Category</a><br />
            <br />
            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
            <?php endif; ?>
            <table class="table table-striped" id="Product">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Edit Action</th>
                        <th>Delete Action</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php if($products): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product['id']); ?></td>
                        <td><?php echo e($product['name']); ?></td>
                        <td><?php echo e($product['price']); ?></td>
                        <td><?php echo e($product['category']); ?></td>
                        <td><a href="<?php echo e(action('ProductController@edit', $product['id'])); ?>" class="btn btn-warning">Edit</a></td>
                        <td>
                            <form action="<?php echo e(action('ProductController@destroy', $product['id'])); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input name="_method" type="hidden" value="DELETE">
                                <button class="btn btn-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>NO DATA AVAILABLE</td>    
                    </tr>
                    <?php endif; ?>    
                </tbody>
            </table>
        </div>
    </body>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript">
$(document).ready(function () {
    $("#Product").DataTable({
        "paging": true,
        "autoWidth": true,
        "searching": false,
        "ordering": false,
        "lengthMenu": [2, 5, 10, 25, 50, 75, 100],
        "lengthChange": true,
    });
});
    </script>
</html>

