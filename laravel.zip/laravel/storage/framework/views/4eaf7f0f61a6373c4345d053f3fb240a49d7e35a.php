<?php ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Index Page</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('js/datatables/dataTables.bootstrap.css')); ?>">

    </head>
    <body>
        <div class="container">
            <h1>Category</h1><br />
            <a href="<?php echo e(action('CategoryController@create')); ?>" class="btn btn-success" style="float: right;">ADD</a>
            <a href="<?php echo e(action('ProductController@index')); ?>" class="btn btn-success" style="float: right;">Products</a><br />
            
            <br />
            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
            <?php endif; ?>
            <table class="table table-striped" id="Product">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Edit Action</th>
                        <th>Delete Action</th> 
                        <th></th> 
                    </tr>
                </thead>
                <tbody>
                    <?php if($categories): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category['id']); ?></td>
                        <td><?php echo e($category['name']); ?></td>
                        <td><a href="<?php echo e(action('CategoryController@edit', $category['id'])); ?>" class="btn btn-warning">Edit</a></td>
                        <td>
                            <form action="<?php echo e(action('CategoryController@destroy', $category['id'])); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input name="_method" type="hidden" value="DELETE">
                                <button class="btn btn-danger" type="submit">Delete</button>
                            </form>
                        </td>
                        <td><a href="<?php echo e(url('category_product/'.$category['id'])); ?>" class="btn btn-success">View Products</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>NO DATA AVAILABLE</td>    
                    </tr>
                    <?php endif; ?>    
                </tbody>
            </table>
        </div>
    </body>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript">
$(document).ready(function () {
    $("#Product").DataTable({
        "paging": true,
        "autoWidth": true,
        "searching": false,
        "ordering": false,
        "lengthMenu": [2, 5, 10, 25, 50, 75, 100],
        "lengthChange": true,
    });
});
    </script>
</html>

