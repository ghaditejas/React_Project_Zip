### Launch application in local environment
```
npm run start
```

Launches application with webpack dev server with hot reload

### Lint
```
npm run lint
```

For check sintax errors