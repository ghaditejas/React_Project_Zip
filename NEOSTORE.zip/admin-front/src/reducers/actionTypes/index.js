import createActionType from '../../utils/createActionTypes';

export default createActionType([
  'GLOBAL_UPDATE',
]);
