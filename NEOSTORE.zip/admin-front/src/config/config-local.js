module.exports = {
  adminApi: {
    baseUrl: 'https://dev-admin-api.indigitall.net/v1',
  },
  debugActions: true,
};
