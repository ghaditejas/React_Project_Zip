import config from './config-local';

export default config;
