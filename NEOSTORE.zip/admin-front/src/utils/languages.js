import message from './message';

const languages = {
  es: message('Español'),
  en: message('Inglés'),
};

export default languages;
