import ActionTypes from './actionTypes';
import applicationService from '../../services/applicationService';

export const applicationResponse = response => ({
  type: ActionTypes.APPLICATIONLIST_RESPONSE,
  payload: response,
});

export const applicationRequest = () => async (dispatch) => {
  const applicationRes = await applicationService.getapplication(4);
  dispatch(applicationResponse(applicationRes));
};

export const applicationDetailResponse = (response, applicationId) => ({
  type: ActionTypes.APPLICATIONDETAIL_RESPONSE,
  payload: { response, applicationId },
});

export const applicationDetailRequest = id => async (dispatch) => {
  const applicationDetailRes = await applicationService.getapplicationDetail(id);
  dispatch(applicationDetailResponse(applicationDetailRes, id));
};

export const createApplicationResponse = (response) => {
  if (response.statusCode === 200) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE,
      payload: true,
    };
  }
  return false;
};

export const isDeleting = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETING,
});

export const createApplicationRequest = (id, name, androidCode, iosCode) => async (dispatch) => {
  dispatch(isDeleting());
  const applicationRes = await applicationService.createApplication(id, name, androidCode, iosCode);
  dispatch(createApplicationResponse(applicationRes));
};

export const setCreateAppText = (name, androidCode, iosCode) => ({
  type: ActionTypes.CREATE_APPLICATION_TEXT,
  payload: {
    name,
    androidCode,
    iosCode,
  },
});

export const openAddModal = from => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_ADD_OPEN,
  payload: from,
});

export const closeAddModal = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE,
});

export const openDeleteModal = application => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETE_OPEN,
  payload: application,
});

export const closeDeleteModal = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETE_CLOSE,
});

export const deleteResponse = (res) => {
  if (res === true) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_DELETION_OK,
      payload: true,
    };
  }
  return {
    type: ActionTypes.APPLICATIONLIST_MODAL_DELETION_ERROR,
    payload: false,
  };
};

export const deleteApplicationRequest = (id, externalAppId) => async (dispatch) => {
  dispatch(isDeleting());
  const response = await applicationService.deleteApplication(id, externalAppId);
  dispatch(deleteResponse(response));
};

export const checkboxEnable = application => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX,
  payload: application,
});

export const enableAll = response => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_ALL,
  payload: response,
});

export const editApplicationResponse = (response) => {
  if (response.statusCode === 200) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE_EDIT,
      payload: true,
    };
  }
  return false;
};

export const editApplicationRequest = (externalId, id, name, androidCode, iosCode) => async (dispatch) => {
  dispatch(isDeleting());
  const editApplicationRes = await applicationService.editApplication(externalId, id, name, androidCode, iosCode);
  dispatch(editApplicationResponse(editApplicationRes));
};

export const checkboxEnableApplication = application => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX_STATUS,
  payload: application,
});
