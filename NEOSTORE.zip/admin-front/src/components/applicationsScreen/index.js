import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Typography from 'material-ui/Typography';
import Card, { CardContent } from 'material-ui/Card';
import { withStyles } from 'material-ui/styles';
import { CircularProgress } from 'material-ui/Progress';
import TextField from 'material-ui/TextField';
import SearchBar from 'material-ui-search-bar';
import { Warning } from 'material-ui-icons';
import Checkbox from 'material-ui/Checkbox';
import Grid from 'material-ui/Grid';
import { Link } from 'react-router-dom';
import Dialog, { DialogTitle, DialogContent } from 'material-ui/Dialog';
import Button from 'material-ui/Button';
import Divider from 'material-ui/Divider';
import { SnackbarContent } from 'material-ui/Snackbar';
import Table, { TableBody, TableCell, TableHead, TableRow } from 'material-ui/Table';
import message from '../../utils/message';
import styles from './styles';
import { applicationRequest,
  openDeleteModal, closeDeleteModal,
  openAddModal, deleteApplicationRequest,
  applicationDetailRequest, closeAddModal,
  createApplicationRequest, setCreateAppText, checkboxEnable,
  editApplicationRequest, enableAll, checkboxEnableApplication } from './actions';

const ApplicationItem = ({
  classes, application, IsChecked, checkboxEnableCall,
}) => (
   <TableRow hover>
      <TableCell>
        <Checkbox color='primary'
        checked = {IsChecked}
        onChange={() => {
          checkboxEnableCall(application);
        }}/>
        </TableCell>
        <TableCell>
        <Typography variant='subheading' className={classes.inline} noWrap>
          {application.name}
        </Typography>
        </TableCell>
      <TableCell>
        <Typography variant='subheading' className={classes.inline} noWrap>
          {application.androidCode}
        </Typography>
        </TableCell>
      <TableCell>
        <Typography variant='subheading' className={classes.inline} noWrap>
          {application.iosCode}
        </Typography>
        </TableCell>
    </TableRow>
);


ApplicationItem.propTypes = {
  application: PropTypes.object.isRequired,
  classes: PropTypes.object.isRequired,
  IsChecked: PropTypes.bool.isRequired,
  checkboxEnableCall: PropTypes.func.isRequired,
};

const DeleteBox = ({
  classes, onClose, application, deleteHandler,
}) => (
    <div>
    <Warning color='disabled' className={classes.modalIcon} />
    <Typography>
      {message('¿Está seguro de querer eliminar la campaña')}{' '}
      <strong> &quot;{application.name}&quot; </strong>
      {message('de la plataforma ?')}
    </Typography>
    <br />
    <div className={classes.right}>
      <Divider />
      <br />
      <Button variant='raised' color='primary' onClick={() => onClose()}>
        {message('Cancelar')}
      </Button>
      <Button
        variant='raised'
        color='secondary'
        onClick={() => {
          const externalApp = [];
          externalApp.push(application.id);
          deleteHandler(4, externalApp);
        }}
      >
        {message('Eliminar')}
      </Button>
    </div>
  </div>
);

DeleteBox.propTypes = {
  classes: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
  deleteHandler: PropTypes.func,
  application: PropTypes.object,
};

const DeleteModal = ({
  classes,
  isOpened,
  onClose,
  application,
  deleteHandler,
  isDeletingApplication,
  isDeleted,
  isDeletedError,
  checkApplicationData,
}) => {
  let view;
  if (isDeletingApplication) {
    view = (
      <div className={classes.progress}>
        <CircularProgress />
      </div>
    );
  } else if (isDeleted) {
    view = (
      <SnackbarContent
        className={classes.snackbarOk}
        message={message('aplicación borrada correctamente')}
      />
    );
  } else if (isDeletedError) {
    view = (
      <SnackbarContent
        className={classes.snackbarError}
        message={message('Error al borrar aplicación')}
      />
    );
  } else if (!checkApplicationData.id) {
    view = (
          <SnackbarContent
            className={classes.snackbarError}
            message={message('Please Select a CheckBox')}
          />
    );
  } else {
    view = (
      <DeleteBox
        classes={classes}
        onClose={onClose}
        application={application}
        deleteHandler={deleteHandler}
      />
    );
  }
  return (
    <Dialog open={isOpened} onClose={onClose}>
      <DialogTitle> {message('Eliminar aplicación')}</DialogTitle>
      <DialogContent className={classes.modalContent}>{view}</DialogContent>
    </Dialog>
  );
};

DeleteModal.propTypes = {
  isOpened: PropTypes.bool.isRequired,
  classes: PropTypes.object.isRequired,
  onClose: PropTypes.func.isRequired,
  deleteHandler: PropTypes.func,
  application: PropTypes.object,
  isDeletingApplication: PropTypes.bool.isRequired,
  isDeleted: PropTypes.bool.isRequired,
  isDeletedError: PropTypes.bool.isRequired,
  checkApplicationData: PropTypes.object.isRequired,
};

const AddModal = ({
  isOpened,
  classes,
  isClose,
  createApplication,
  setCreateAppTextCall,
  ApplicationName,
  applicationAndroidCode,
  applicationIOSCode,
  from,
  checkApplicationData,
  editApplication,
  isDeletingApplication,
}) => {
  let heading = '';
  let view;
  if (isDeletingApplication) {
    if (from === 'newApplication') {
      heading = 'Creating new Application';
    } else {
      heading = 'Editing an application';
    }
    view = (
      <div className={classes.progress}>
        <CircularProgress />
      </div>
    );
    return (
    <Dialog open={isOpened} onClose={isClose}>
      <DialogTitle> {message(heading)}</DialogTitle>
      <DialogContent className={classes.modalContent}>{view}</DialogContent>
    </Dialog>
    );
  } else if (from === 'newApplication' && isOpened) {
    heading = 'Enlazar nueva aplicación';
    view = (
    <div>
      <Typography variant='body2' className={classes.dialogText}>
        {
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi quis tellus eleifend, interdum lectus ut.'
        }
      </Typography>
      <div className={classes.fields}>
        <TextField
          fullWidth={true}
          label='Name'
          onChange={text =>
            setCreateAppTextCall(
              text.target.value,
              applicationAndroidCode,
              applicationIOSCode,
            )
          }
        />
      </div>
      <div className={classes.fields}>
        <TextField
          fullWidth={true}
          label='Android Code'
          onChange={text =>
            setCreateAppTextCall(
              ApplicationName,
              text.target.value,
              applicationIOSCode,
            )
          }
        />
      </div>
      <div className={classes.fields}>
        <TextField
          fullWidth={true}
          label='Ios Code'
          onChange={text =>
            setCreateAppTextCall(
              ApplicationName,
              applicationAndroidCode,
              text.target.value,
            )
          }
        />
      </div>
      <div className={classes.cardiTem}>
        <Button
          variant='raised'
          color='primary'
          onClick={() => {
            isClose();
          }}
        >
          {message('CANCELAR')}
        </Button>

        <Button
          variant='raised'
          color='primary'
          onClick={() => {
            if (
              ApplicationName !== '' &&
              applicationAndroidCode !== '' &&
              applicationIOSCode !== ''
            ) {
              createApplication(
                4,
                ApplicationName,
                applicationAndroidCode,
                applicationIOSCode,
              );
            }
          }}
        >
          {message('CREAR APLICACIóN')}
        </Button>
      </div>
    </div>
    );
  } else if (from !== 'newApplication' && isOpened) {
    if (checkApplicationData.id) {
      heading = 'Ficha de "NombreAplicación"';
      view = (
      <div>
        <Typography variant='body2' className={classes.dialogText}>
          {
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi quis tellus eleifend, interdum lectus ut.'
          }
        </Typography>
        <div className={classes.fields}>
          <TextField
            fullWidth={true}
            label='Name'
            defaultValue={ApplicationName}
            onChange={text =>
              setCreateAppTextCall(
                text.target.value,
                applicationAndroidCode,
                applicationIOSCode,
              )}
          />
        </div>
        <div className={classes.fields}>
          <TextField
            fullWidth={true}
            label='Android Code'
            defaultValue={applicationAndroidCode}
            onChange={text =>
              setCreateAppTextCall(
                ApplicationName,
                text.target.value,
                applicationIOSCode,
              )}
          />
        </div>
        <div className={classes.fields}>
          <TextField
            fullWidth={true}
            label='Ios Code'
            defaultValue={applicationIOSCode}
            onChange={text =>
              setCreateAppTextCall(
                ApplicationName,
                applicationAndroidCode,
                text.target.value,
              )}
          />
        </div>
        <div className={classes.cardiTem}>
          <Button
            variant='raised'
            color='primary'
            onClick={() => {
              isClose();
            }}
          >
            {message('CANCELAR')}
            </Button>
          <Button
            variant='raised'
            color='primary'
            onClick={() => {
              if (
                ApplicationName !== '' &&
                applicationAndroidCode !== '' &&
                applicationIOSCode !== ''
              ) {
                editApplication(
                  checkApplicationData.id,
                  4,
                  ApplicationName,
                  applicationAndroidCode,
                  applicationIOSCode,
                );
              }
            }}
          >
            {message('EDIT APLICACIóN')}
          </Button>
        </div>
      </div>
      );
    } else {
      view = (
    <div>
      <SnackbarContent
        className={classes.snackbarError}
        message={message('Please Select a CheckBox')}
      />
      <div className={classes.cardiTem}>
        <Button
          variant='raised'
          color='primary'
          onClick={() => {
            isClose();
          }}
        >
          {message('Ok')}
        </Button>
        </div>
    </div>
      );
    }
  }
  return (
    <Dialog open={isOpened}>
      <DialogTitle> {message(heading)}</DialogTitle>
      <DialogContent className={classes.modalContent}>{view}</DialogContent>
    </Dialog>
  );
};

AddModal.propTypes = {
  isOpened: PropTypes.bool.isRequired,
  classes: PropTypes.object.isRequired,
  isClose: PropTypes.func.isRequired,
  createApplication: PropTypes.func.isRequired,
  setCreateAppTextCall: PropTypes.func.isRequired,
  ApplicationName: PropTypes.string.isRequired,
  applicationAndroidCode: PropTypes.string.isRequired,
  applicationIOSCode: PropTypes.string.isRequired,
  from: PropTypes.string.isRequired,
  checkApplicationData: PropTypes.object.isRequired,
  editApplication: PropTypes.func.isRequired,
  isDeletingApplication: PropTypes.bool.isRequired,
};

class applicationsScreen extends Component {
  constructor(props) {
    super(props);
    this.props = props;

    this.state = {
      chkAddPopup: false,
      data: this.props.applicationList,
      searchText: '',
      searchData: [],
    };
  }

  componentWillMount() {
    this.props.applicationDetail(4);
  }

  componentWillReceiveProps(newProps) {
    if (this.props.createApplicationStatus !== newProps.createApplicationStatus ||
      this.props.isDeleted !== newProps.isDeleted || this.props.editApplicationStatus !== newProps.editApplicationStatus) {
      this.setState({ searchText: '' });
      this.setState({ searchData: [] });
      newProps.applicationDetail(4);
    }
  }

  showSearchResult(text) {
    const arrData = [];
    this.props.applicationDetailList.map((item) => {
      if ((item.name.toUpperCase()).match(text.toUpperCase()) ||
      (item.androidCode.toUpperCase()).match(text.toUpperCase()) || (item.iosCode.toUpperCase()).match(text.toUpperCase())) {
        arrData.push(item);
      }
      return false;
    });
    if (text === '') {
      this.setState({ searchData: [] });
    } else {
      this.setState({ searchData: arrData });
    }
  }

  check(id) {
    let index = 0;
    this.props.checkboxEnableList.map((item, i) => {
      if (item.id === id) {
        index = i;
      }
      return false;
    });
    return index;
  }

  render() {
    let view;
    if (this.props.isRequesting === true) {
      view = (
        <div className={this.props.classes.progress}>
          <CircularProgress />
        </div>
      );
    } else {
      view = (
        <Table className={this.props.classes.table}>
        <TableHead>
        <TableRow className={this.props.classes.tableHeader}>
          <TableCell>
              <Checkbox color='primary' checked = {this.props.isEnableAll} onChange = {(evt, checked) => {
                if (checked) {
                  this.props.enableAll(true);
                } else {
                  this.props.enableAll(false);
                }
            }}/>
            </TableCell>
            <TableCell>
              <Typography variant='title' className={this.props.classes.nombre}>
                {message('Nombre')}
              </Typography>
            </TableCell>
             <TableCell>
              <Typography noWrap variant='title' className={this.props.classes.paquete}>
                {message('Paquete')}
              </Typography>
            </TableCell>
            <TableCell>
              <Typography noWrap variant='title' className={this.props.classes.paquete}>
                {message('URL Scheme')}
              </Typography>
             </TableCell>
          </TableRow>
          </TableHead>
          <TableBody>
            {this.state.searchData.length === 0 ? this.props.applicationDetailList.map(
              (item, index) => <ApplicationItem
                      classes={this.props.classes}
                      application={item}
                      IsChecked = {this.props.checkboxEnableList[index].ischecked}
                      checkboxEnableCall = {this.props.checkboxEnableApplication}
                      key={index}
                    />
              , this,
            ) : this.state.searchData.map((item, index) => {
                const status = this.check(item.id);
                return (
                    <ApplicationItem
                      classes={this.props.classes}
                      application={item}
                      IsChecked = {this.props.checkboxEnableList[status].ischecked}
                      checkboxEnableCall = {this.props.checkboxEnableApplication}
                      key={index}
                    />
                );
              }, this)
          }
          </TableBody>
        </Table>
      );
    }

    return (
      <div>
        <Grid container>
          <Grid item xs={6}>
            <Typography noWrap variant='headline'>
              {message('Aplicaciones externas conectadas')}
            </Typography>
          </Grid>
          <Grid item xs={6} className={this.props.classes.headButton}>
            <Link to={'/applications/new'}>
              <Button
                variant='raised'
                color='primary'
                onClick={() => {
                  this.props.CheckAddModal('newApplication');
                }}
              >
                {message('Nueva campaña')}
              </Button>
            </Link>
          </Grid>
          <Grid item xs={12}>
            <Card>
              <CardContent>
                <Grid container>
                  <Grid item xs={12} sm={8} md={9}>
                    <Typography noWrap variant='subheading'>
                      {' '}
                      {message('Listado de aplicaciones')}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} sm={4} md={3} >
                    <Typography noWrap variant='subheading' className={this.props.classes.message}>
                      {' '}
                      {this.props.applicationDetailList.length}{' '}
                      {message('aplicaciones')}
                    </Typography>
                  </Grid>
                  <Divider />

                  <Grid
                    item
                    xs={12}
                    sm={3}
                    md={2}
                    className={this.props.classes.titleButton}
                  >
                    <Link to={'/applications/new'}>
                      <Button
                        variant='raised'
                        color='primary'
                        onClick={() => { this.props.CheckAddModal('editApplication'); }}
                      >
                        {message('EDITAR')}
                      </Button>
                    </Link>
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={3}
                    md={2}
                    className={this.props.classes.titleButton}
                  >
                    <Link to={'/applications'}>
                      <Button
                        variant='raised'
                        color='primary'
                        onClick={() => {
                          this.props.modalDeleteHandler(this.props.enabledApplication);
                        }}
                      >
                        {message('ELIMINAR')}
                      </Button>
                    </Link>
                  </Grid>

                  <Grid item xs={4}></Grid>

                  <Grid item xs={4}>
                    <SearchBar
                      onChange={(text) => {
                        this.setState({ searchText: text });
                        this.showSearchResult(text);
                      }}
                      onRequestSearch={(text) => {
                       this.showSearchResult(text);
                      }}
                      className={this.props.classes.filter}
                      value={this.state.searchText}
                    />
                  </Grid>

                  <Divider />
                  <Grid item xs={12} sm={3} md={2} />

                  <Grid item xs={12}>
                  {view}
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        <AddModal
        classes={this.props.classes}
        isOpened={this.props.isAddModalOpened}
        isClose={this.props.closeAddModal}
        createApplication={this.props.createApplication}
        editApplication={this.props.editApplication}
        ApplicationName={this.props.ApplicationName}
        applicationAndroidCode={this.props.applicationAndroidCode}
        applicationIOSCode={this.props.applicationIOSCode}
        setCreateAppTextCall={this.props.setCreateAppText}
        from={this.props.chkModalFrom}
        checkApplicationData={this.props.enabledApplication}
        isDeletingApplication={this.props.isDeletingApplication}
        />

        <DeleteModal
          classes={this.props.classes}
          isOpened={this.props.isDeleteModalOpened}
          applicationName='test campaign'
          onClose={this.props.deleteModalClose}
          application={this.props.selectedApplication}
          isDeletingApplication={this.props.isDeletingApplication}
          deleteHandler={this.props.deleteHandler}
          isDeleted={this.props.isDeleted}
          isDeletedError={this.props.isDeletedError}
          checkApplicationData={this.props.enabledApplication}
        />
      </div>
    );
  }
}

applicationsScreen.propTypes = {
  isRequesting: PropTypes.bool.isRequired,
  classes: PropTypes.object.isRequired,
  applicationList: PropTypes.array.isRequired,
  initialize: PropTypes.func.isRequired,
  createApplication: PropTypes.func.isRequired,
  modalDeleteHandler: PropTypes.func.isRequired,
  CheckAddModal: PropTypes.func.isRequired,
  closeAddModal: PropTypes.func.isRequired,
  applicationDetail: PropTypes.func.isRequired,
  applicationDetailList: PropTypes.array.isRequired,
  isDeleteModalOpened: PropTypes.bool.isRequired,
  isAddModalOpened: PropTypes.bool.isRequired,
  deleteModalClose: PropTypes.func.isRequired,
  selectedApplication: PropTypes.object.isRequired,
  isDeletingApplication: PropTypes.bool.isRequired,
  deleteHandler: PropTypes.func.isRequired,
  isDeleted: PropTypes.bool.isRequired,
  isDeletedError: PropTypes.bool.isRequired,
  setCreateAppText: PropTypes.func.isRequired,
  ApplicationName: PropTypes.string.isRequired,
  applicationAndroidCode: PropTypes.string.isRequired,
  applicationIOSCode: PropTypes.string.isRequired,
  isEnableAll: PropTypes.bool.isRequired,
  enableAll: PropTypes.func.isRequired,
  editApplication: PropTypes.func.isRequired,
  chkModalFrom: PropTypes.string.isRequired,
  checkboxEnable: PropTypes.func.isRequired,
  checkboxEnableApplication: PropTypes.func.isRequired,
  enabledApplication: PropTypes.object.isRequired,
  checkboxEnableList: PropTypes.array.isRequired,
  editApplicationStatus: PropTypes.bool.isRequired,
  createApplicationStatus: PropTypes.bool.isRequired,
};

const mapStateToProps = state => ({
  applicationList: state.applicationList.get('applicationList'),
  applicationDetailList: state.applicationList.get('applicationDetail'),
  isRequesting: state.applicationList.get('requesting'),
  isDeleteModalOpened: state.applicationList.get('isDeleteModalOpened'),
  isAddModalOpened: state.applicationList.get('isAddModalOpened'),
  selectedApplication: state.applicationList.get('selectedApplication'),
  isDeletingApplication: state.applicationList.get('isDeletingApplication'),
  isDeleted: state.applicationList.get('deletionOk'),
  isDeletedError: state.applicationList.get('deletionError'),
  ApplicationName: state.applicationList.get('ApplicationName'),
  applicationAndroidCode: state.applicationList.get('applicationAndroidCode'),
  applicationIOSCode: state.applicationList.get('applicationIOSCode'),
  createApplicationStatus: state.applicationList.get('createApplicationStatus'),
  enabledApplication: state.applicationList.get('enabledApplication'),
  chkModalFrom: state.applicationList.get('chkModalFrom'),
  isEnableAll: state.applicationList.get('isEnableAll'),
  editApplicationStatus: state.applicationList.get('editApplicationStatus'),
  checkboxEnableList: state.applicationList.get('checkboxEnableList'),
});

const mapDispatchToProps = dispatch => ({
  initialize: appId => dispatch(applicationRequest(appId)),
  modalDeleteHandler: application => dispatch(openDeleteModal(application)),
  deleteModalClose: () => dispatch(closeDeleteModal()),
  CheckAddModal: from => dispatch(openAddModal(from)),
  closeAddModal: () => dispatch(closeAddModal()),
  deleteHandler: (id, externalAppId) => dispatch(deleteApplicationRequest(id, externalAppId)),
  applicationDetail: id => dispatch(applicationDetailRequest(id)),
  setCreateAppText: (name, androidCode, iosCode) => dispatch(setCreateAppText(name, androidCode, iosCode)),
  createApplication: (id, name, androidCode, iosCode) => dispatch(createApplicationRequest(id, name, androidCode, iosCode)),
  checkboxEnable: application => dispatch(checkboxEnable(application)),
  enableAll: isEnableAll => dispatch(enableAll(isEnableAll)),
  editApplication: (externalId, id, name, androidCode, iosCode) => dispatch(editApplicationRequest(externalId, id, name, androidCode, iosCode)),
  checkboxEnableApplication: application => dispatch(checkboxEnableApplication(application)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(applicationsScreen));
