import ActionTypes from './actionTypes';
import ApplicationListModel from './model';
import createReducer from '../../utils/createReducer';

const applicationListResponse = (state, action) =>
  state.set('applicationList', action.payload);

const applicationDetailResponse = (state, action) => {
  const arr = [];
  action.payload.response.map((item) => {
    arr.push({ id: item.id, ischecked: false });
    return false;
  });
  return state
    .set('checkboxEnableList', arr)
    .set('applicationDetail', action.payload.response)
    .set('requesting', false)
    .set('createApplicationStatus', false);
};

const createApplicationResponse = (state, action) =>
  state.set('createApplication', action.payload).set('requesting', false);

const openDeleteModal = (state, action) =>
  state
    .set('isDeleteModalOpened', true)
    .set('isDeletingApplication', false)
    .set('deletionOk', false)
    .set('deletionError', false)
    .set('selectedApplication', action.payload);

const closeDeleteModal = state => state.set('isDeleteModalOpened', false);

const setCreateAppText = (state, action) => state.set('ApplicationName', action.payload.name)
  .set('applicationAndroidCode', action.payload.androidCode)
  .set('applicationIOSCode', action.payload.iosCode);


const openAddModal = (state, action) =>

  state.set('isAddModalOpened', true).set('chkModalFrom', action.payload).set('editApplicationStatus', false);

const closeAddModal = (state, action) => {
  if (action.payload === true) {
    return state
      .set('isAddModalOpened', false)
      .set('createApplicationStatus', action.payload)
      .set('isDeletingApplication', false);
  }
  return state.set('isAddModalOpened', false);
};

const isDeletingApplication = state => state.set('isDeletingApplication', true);

const deletionOk = state =>
  state
    .set('isDeletingApplication', false)
    .set('deletionError', false)
    .set('deletionOk', true)
    .set('enabledApplication', {})
    .set('ApplicationName', '')
    .set('applicationAndroidCode', '')
    .set('applicationIOSCode', '');

const deletionError = state =>
  state
    .set('isDeletingApplication', false)
    .set('deletionOk', false)
    .set('deletionError', true);

const checkboxEnable = (state, action) =>
  state
    .set('enabledApplication', action.payload)
    .set('ApplicationName', action.payload.name)
    .set('applicationAndroidCode', action.payload.androidCode)
    .set('applicationIOSCode', action.payload.iosCode);

const enableAll = (state, action) => {
  const List = state.get('checkboxEnableList');
  List.map((item) => {
    const i = item;
    i.ischecked = action.payload;
    return false;
  });

  return state
    .set('isEnableAll', action.payload)
    .set('checkboxEnableList', List)
    .set('enabledApplication', {})
    .set('ApplicationName', '')
    .set('applicationAndroidCode', '')
    .set('applicationIOSCode', '');
};

const editStatus = (state, action) => {
  const List = state.get('checkboxEnableList');
  List.map((item) => {
    const i = item;
    i.ischecked = false;
    return false;
  });

  return state
    .set('checkboxEnableList', List)
    .set('isDeletingApplication', false)
    .set('isAddModalOpened', false)
    .set('editApplicationStatus', action.payload)
    .set('enabledApplication', {})
    .set('ApplicationName', '')
    .set('applicationAndroidCode', '')
    .set('applicationIOSCode', '');
};

const checkboxEnableStatus = (state, action) => {
  const List = state.get('checkboxEnableList');
  List.map((item) => {
    const i = item;
    const a = action;
    if (item.id === action.payload.id) {
      if (item.ischecked === true) {
        i.ischecked = false;
        a.payload = [];
      } else {
        i.ischecked = true;
      }
    } else {
      i.ischecked = false;
    }
    return false;
  });
  if (!action.payload.id) {
    return state
      .set('isEnableAll', false)
      .set('checkboxEnableList', List)
      .set('enabledApplication', {})
      .set('ApplicationName', '')
      .set('applicationAndroidCode', '')
      .set('applicationIOSCode', '');
  }
  return state
    .set('isEnableAll', false)
    .set('checkboxEnableList', List)
    .set('enabledApplication', action.payload)
    .set('ApplicationName', action.payload.name)
    .set('applicationAndroidCode', action.payload.androidCode)
    .set('applicationIOSCode', action.payload.iosCode);
};

const handlers = {
  [ActionTypes.APPLICATIONLIST_RESPONSE]: applicationListResponse,
  [ActionTypes.APPLICATIONDETAIL_RESPONSE]: applicationDetailResponse,
  [ActionTypes.CREATE_APPLICATION_RESPONSE]: createApplicationResponse,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_OPEN]: openAddModal,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE]: closeAddModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETE_OPEN]: openDeleteModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETE_CLOSE]: closeDeleteModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETING]: isDeletingApplication,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETION_OK]: deletionOk,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETION_ERROR]: deletionError,
  [ActionTypes.CREATE_APPLICATION_TEXT]: setCreateAppText,
  [ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX]: checkboxEnable,
  [ActionTypes.APPLICATIONLIST_ENABLE_ALL]: enableAll,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE_EDIT]: editStatus,
  [ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX_STATUS]: checkboxEnableStatus,
};

export default createReducer(handlers, new ApplicationListModel());
