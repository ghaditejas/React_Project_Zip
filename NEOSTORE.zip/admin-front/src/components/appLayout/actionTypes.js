import createActionType from '../../utils/createActionTypes';

export default createActionType([
  'MAIN_MENU_COLLAPSE',
  'MAIN_MENU_EXPAND',
  'MAIN_MENU_TOGGLE',
  'MAIN_MENU_ITEM_COLLAPSE',
  'MAIN_MENU_ITEM_EXPAND',
  'MAIN_MENU_ITEM_TOGGLE',
]);
