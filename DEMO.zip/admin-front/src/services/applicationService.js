import config from '../config';
import authService from './authService';

/**
 * Service for managing applications
 */
class applicationService {
  /**
   * Get all applications list of an application
   * @param {number} id
   */
  static async getapplication() {
    return fetch('http://180.149.245.182:3008/api/products?filter=%7B%22limit%22%3A%226%22%2C%22include%22%3A%22images%22%7D')
      .then(featureProducts => featureProducts.json())
      .then(function (data) {
        return data;
      })
  }

  static async getbanner() {
    return fetch('http://180.149.245.182:3008/api/images?filter=%7B%22limit%22%3A%223%22%2C%22inlcude%22%3A%22product%22%7D')
      .then(banner => banner.json())
      .then(function (data) {
        return data;
      })
  }

  static async loginProcess(email, password) {
    // console.log('asdaass');
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "email": email,
        "password": password
      })
    };
    return fetch('http://180.149.245.182:3008/api/user_accounts/login', options)
      .then(login => login.json())
      .then(function (data) {
        return data;
      })
  }

  static async getUserDataProcess(accessToken, userId) {
    let url = "http://180.149.245.182:3008/api/user_accounts/" + userId + "?access_token=" + accessToken;
    return fetch(url)
      .then(userData => userData.json())
      .then(function (data) {
        return data;
      })
  }

  static async getUserAddressesProcess(accessToken, userId) {
    let url = "http://180.149.245.182:3008/api/user_accounts/" + userId + "/addresses?access_token=" + accessToken;
    return fetch(url)
      .then(userData => userData.json())
      .then(function (data) {
        return data;
      })
  }

  static async updateUserProfileProcess(userProfile, accessToken, userId) {
    // let date_birth = new Date(userProfile.birth_date);
    // var  birth_date_string = date_birth.toISOString();
    const options = {
      method: 'PATCH',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "first_name": userProfile.first_name,
        "last_name": userProfile.last_name,
        "gender": userProfile.gender,
        "birth_date": userProfile.birth_date,
        "mobile": userProfile.mobile,
        "email": userProfile.email,
      })
    };
    let url = "http://180.149.245.182:3008/api/user_accounts/" + userId + "?access_token=" + accessToken;
    return fetch(url, options)
      .then(login => login.json())
      .then(function (data) {
        return data;
      })
  }

  static async addUserAddressProcess(newaddress, accessToken, userId) {
    // let date_birth = new Date(userProfile.birth_date);
    // var  birth_date_string = date_birth.toISOString();
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "fulladdress": newaddress.fulladdress,
        "city": newaddress.city,
        "state": newaddress.state,
        "pincode": newaddress.pincode,
        "country": newaddress.country,
      })
    };
    let url = "http://180.149.245.182:3008/api/addresses/AddAddress/" + userId + "?access_token=" + accessToken;
    return fetch(url, options)
      .then(login => login.json())
      .then(function (data) {
        return data;
      })
  }

  static async deleteAddressProcess(addressId, accessToken, userId) {
    const options = {
      method: 'DELETE',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
    };
    let url = "http://180.149.245.182:3008/api/addresses/" + addressId + "?access_token=" + accessToken;
    return fetch(url, options)
      .then(userData => userData.json())
      .then(function (data) {
        return data;
      })
  }

  static async getAddressProcess(addressId, accessToken, userId) {
    let url = "http://180.149.245.182:3008/api/addresses/" + addressId + "?access_token=" + accessToken;
    return fetch(url)
      .then(userData => userData.json())
      .then(function (data) {
        return data;
      })
  }

  static async editAddressProcess(editAddress, accessToken, addressId) {
    const options = {
      method: 'PATCH',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "fulladdress": editAddress.fulladdress,
        "city": editAddress.city,
        "state": editAddress.state,
        "pincode": editAddress.pincode,
        "country": editAddress.country,
      })
    };
    let url = "http://180.149.245.182:3008/api/addresses/" + addressId + "?access_token=" + accessToken;
    return fetch(url, options)
      .then(editAddress => editAddress.json())
      .then(function (data) {
        return data;
      })
  }

  static async getAllProducts(filter) {
    let conditions = JSON.stringify(filter)
    let url = "http://180.149.245.182:3008/api/products?filter=" + conditions;
    return fetch(url)
      .then(allProducts => allProducts.json())
      .then(function (data) {
        return data;
      })
  }

  static async getAllCategories() {
    let url = "http://180.149.245.182:3008/api/categories";
    return fetch(url)
      .then(allCategories => allCategories.json())
      .then(function (data) {
        return data;
      })
  }

  static async getAllColour() {
    let url = "http://180.149.245.182:3008/api/colors";
    return fetch(url)
      .then(allColours => allColours.json())
      .then(function (data) {
        return data;
      })
  }

  static async addToCart(cartDetails) {
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "userid": cartDetails.userId,
        "products": [{
          "productId": cartDetails.productid,
          "qty": 1
        }]
      }),
    };
    let url = "http://180.149.245.182:3008/api/shoppingcarts/addToCart";
    return fetch(url, options)
      .then(cartData => cartData.json())
      .then(function (data) {
        return data;
      })
  }

  static async getCartProcess(accessToken, userId) {
    let url = "http://180.149.245.182:3008/api/shoppingcarts/getCart?userid=" + userId;
    return fetch(url)
      .then(getcartData => getcartData.json())
      .then(function (data) {
        return data;
      })
  }

  static async removeFromCartProcess(productId) {
    const options = {
      method: 'DELETE',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
    };
    let url = "http://180.149.245.182:3008/api/shoppingcarts/" + productId;
    return fetch(url, options)
      .then(deleteCartData => deleteCartData.json())
      .then(function (data) {
        return data;
      })
  }

  static async updateCartProcess(cartData, quantity, userId) {
    const options = {
      method: 'PATCH',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "userId": userId,
        "productid": cartData.productId,
        "productqty": quantity,
        "instock": true,
        "product_cost": cartData.product_cost,
        "id": cartData.id
      }),
    };
    let url = "http://180.149.245.182:3008/api/shoppingcarts";
    return fetch(url, options)
      .then(updateCartData => updateCartData.json())
      .then(function (data) {
        return data;
      })
  }

  static async makeOrderProcess(card, accessToken, userId, email, product, addressId) {
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        addressId: addressId,
        card: {
          cvc: card.cvc,
          exp_month: card.exp_month,
          exp_year: card.exp_year,
          number: card.number
        },
        email: email,
        products: product,
        userId: userId
      }),
    };
    let url = "http://180.149.245.182:3008/api/orders/order";
    return fetch(url, options)
      .then(OrderStatus => OrderStatus.json())
      .then(function (data) {
        return data;
      })
  }

  static async getOrderProcess(accessToken, userId) {
    const options = {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
    };
    let url = "http://180.149.245.182:3008/api/orders/allorderofuser/" + userId;
    return fetch(url, options)
      .then(OrderDetails => OrderDetails.json())
      .then(function (data) {
        return data;
      })
  }

  static async getProductProcess(productId) {
    let url = "http://180.149.245.182:3008/api/products/" + productId + "?filter=%7B%22include%22%3A%22images%22%7D";
    return fetch(url)
      .then(productDetails => productDetails.json())
      .then(function (data) {
        return data;
      })
  }

  static async updateProductRatingProcess(productId, rating, accessToken, userId) {
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "user_id": userId,
        "product_id": productId,
        "rating": rating,
      }),
    };
    let url = "http://180.149.245.182:3008/api/ratings/rateProduct?access_token=" + accessToken;
    return fetch(url, options)
      .then(updateRating => updateRating.json())
      .then(function (data) {
        return data;
      })
  }

  static async userRegisterProcess(registerDetails) {
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "first_name": "",
        "last_name": "",
        "gender": registerDetails.gender,
        "email": registerDetails.email,
        "password": registerDetails.password,
        "phone_no": registerDetails.phone_no,
        "username": "",
        "role": "AppUser",
        "orderId": "",
        "shoppingcartId": "",
        "is_active": true,
        "birth_of_date": 0
      }),
    };
    let url = "http://180.149.245.182:3008/api/user_accounts/";
    return fetch(url, options)
      .then(Register => Register.json())
      .then(function (data) {
        return data;
      })
  }

  static async contactAdminProcess(query, accessToken, userId){
    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }),
      body: JSON.stringify({
        "name":query.name,
        "email":query.email,
        "mobile":query.mobile,
        "subject":query.subject,
        "message":query.message
      }),
    };
    let url = "http://180.149.245.182:3008/api/user_accounts/contactus?access_token="+accessToken;
    return fetch(url, options)
      .then(Contact => Contact.json())
      .then(function (data) {
        return data;
      })
  }

  /**
   * Get application detail
   * @param {number} applicationId
   */

  static async getapplicationDetail(applicationId) {
    const url = `${config.adminApi.baseUrl}/application/${applicationId}/externalApps`;
    const authObject = authService.getUserInfo();

    const options = {
      method: 'GET',
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authObject.userToken}`,
      }),
    };

    try {
      const response = await fetch(url, options);
      console.log('here : //' + url + '//' + "Bearer " + authObject.userToken);
      const resData = await response.json();
      console.log('here : //' + JSON.stringify(resData));
      if (response.ok) {
        return resData.data;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Add application 
   * @param {number} applicationId
   */

  static async createApplication(applicationId, applicationName, androidCode, iosCode) {
    const url = `${config.adminApi.baseUrl}/application/${applicationId}/externalApps`;
    const authObject = authService.getUserInfo();

    const options = {
      method: 'POST',
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authObject.userToken}`,
      }),
      body: JSON.stringify({
        "externalApps": [
          {
            "name": applicationName,
            "androidCode": androidCode,
            "iosCode": iosCode
          }
        ]
      })
    };

    try {
      const response = await fetch(url, options);
      const resData = await response.json();
      console.log('here : //' + JSON.stringify(resData));
      if (response.ok) {
        return resData;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
     * Add application 
     * @param {number} applicationId
     */
  static async editApplication(externalId, applicationId, applicationName, androidCode, iosCode) {
    const url = `${config.adminApi.baseUrl}/application/${applicationId}/externalApps?extAppId=${externalId}`;
    const authObject = authService.getUserInfo();

    console.log('Inside api', JSON.stringify({
      "externalApps":
        [{
          "name": applicationName,
          "androidCode": androidCode,
          "iosCode": iosCode
        }]

    }));
    const options = {
      method: 'PUT',
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authObject.userToken}`,
      }),
      body: JSON.stringify({
        "externalApps":
          {
            "name": applicationName,
            "androidCode": androidCode,
            "iosCode": iosCode
          }

      })
    };

    try {
      const response = await fetch(url, options);
      console.log(response);
      const resData = await response.json();
      console.log('here : //' + JSON.stringify(resData));
      if (response.ok) {
        return resData;
      }
      return null;
    } catch (error) {
      return null;
    }
  }


  /**
   * Deletes a application
   * @param {number} id
   */
  static async deleteApplication(id, externalapp) {
    const url = `${config.adminApi.baseUrl}/application/${id}/externalApps`;
    const authObject = authService.getUserInfo();

    const options = {
      method: 'DELETE',
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authObject.userToken}`,
      }),
      body: JSON.stringify({
        "externalApps": externalapp

      })
    };

    try {
      const response = await fetch(url, options);

      if (response.ok) {
        return true;
      }
      return false;
    } catch (error) {
      return false;
    }
  }


}

export default applicationService;
