import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import Router from './routes';
import rootReducer from './reducers';
import configureStore from './utils/configureStore';

const store = configureStore(rootReducer);

ReactDOM.render(
    <div className="layOutWrapper">
        <Provider store={ store }>
            <Router />
        </Provider>
    </div>,
    document.getElementById('root'),
);

