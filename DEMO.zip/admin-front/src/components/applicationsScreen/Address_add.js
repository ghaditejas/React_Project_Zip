import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';

import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import Button from 'react-validation/build/button';
import Textarea from 'react-validation/build/textarea';
import validator from 'validator';
import {
  applicationRequest,
  bannerRequest,
  loggin,
  getUserData,
  getUserAddresses,
  addUserAddress,
} from "./actions";

const required = (value) => {
  if (!value.toString().trim().length) {
    // We can return string or jsx as the 'error' prop for the validated Component
    return(
        <span className="error" style={{color:"red"}}>Require</span>
    );
  }
};

 class Address_add extends Component{
  constructor(props) {
    super(props);
    this.props = props;
    this.state = {
      fulladdress: "",
      pincode: "",
      city: "",
      state: "",
      country: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({[key]:value})
  }

  handleSubmit(event) {
    this.props.addUserAddress(this.state,this.props.loginDetails.id,this.props.loginDetails.userId);
    event.preventDefault();
  }
  render(){
    return (
      <div className="container">
    <div className="container">
      <div className="container-fluid">
        <div className="col-md-12">
          <h4> My Account </h4>
          <hr />
        </div>
        <Side_menu />
        <div className="col-md-9">
          <div className="panel panel-default">
            <div className="panel-body">
              <h4><strong>Add new address</strong></h4>
              <hr />

              <button type="button" className="btn btn-default"><i className="fa fa-map-marker"></i> Set Current Location</button>
              <br />
              <br />
              <Form>

                <div className="row">
                  <div className="col-md-8">
                    <div className="form-group">
                      <label htmlFor="fulladdress">Address</label>
                      <Textarea type="text" className="form-control" name="fulladdress" onChange={this.handleChange} validations={[required]} ></Textarea>
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4">
                    <div className="form-group">
                      <label htmlFor="pincode">Pincode</label>
                      <Input type="number" className="form-control" name="pincode" onChange={this.handleChange} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4">
                    <div className="form-group">
                      <label htmlFor="city">City</label>
                      <Input type="text" className="form-control" name="city" onChange={this.handleChange} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4">
                    <div className="form-group">
                      <label htmlFor="state">State</label>
                      <Input type="text" className="form-control" name="state" onChange={this.handleChange} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4">
                    <div className="form-group">
                      <label htmlFor="country">Country</label>
                      <Input type="text" className="form-control" name="country" onChange={this.handleChange} validations={[required]} />
                    </div>
                  </div>
                </div>

                <hr />
                <Button type="button" onClick={this.handleSubmit} className="btn btn-default btn-lg"><i className="fa fa-floppy-o"></i>Save</Button>
                <Link to="/Address" type="button" className="btn btn-default btn-lg"><i className="fa fa-remove"></i>Cancel</Link>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
      );
  }
}

Address_add.propTypes = {
  addUserAddress: PropTypes.func.isRequired,
 loginDetails: PropTypes.object.isRequired,
 userAddress: PropTypes.array.isRequired,
};

const mapStateToProps = state => {
 return {
    loginDetails: state.applicationList.get("loginDetails"),
    userAddress: state.applicationList.get("userAddress"),
 };
};

const mapDispatchToProps = dispatch => ({
  addUserAddress: (newaddress,accessToken,userId) => dispatch(addUserAddress(newaddress,accessToken,userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Address_add);