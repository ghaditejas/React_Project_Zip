import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
    getCart,
    removeFromCart,
    updateCart,
} from "./actions";

const CartProducts = ({ cartData, cartDelete, quantityChange }) => {
    let total = cartData.product_cost * cartData.productqty;
    // var path = '/Address_edit/' + data.id;
    return (
        <tr>
            <td className="col-sm-8 col-md-6">
                <div className="media">
                    <div className="media-left">
                        <a><img className="media-object cover" src={cartData.images[0].ThumbURL250} /></a>
                    </div>

                    <div className="media-body">
                        <h4 className="media-heading"><a>{cartData.product_name}</a></h4>
                        <h5 className="media-heading"> by <a><small>{cartData.product_producer}</small></a></h5>
                        <span>Status: </span><span className="text-success"><strong>In Stock</strong></span>
                    </div>
                </div>
            </td>
            <td className="col-sm-1 col-md-2 text-center">
                <i className="fa fa-minus-circle" onClick={() => quantityChange(cartData, cartData.productqty - 1)}></i>
                <input type="number" value={cartData.productqty} readOnly="true" className="text-center quantity" />
                <i className="fa fa-plus-circle" onClick={() => quantityChange(cartData, cartData.productqty + 1)}></i>
            </td>
            <td className="col-sm-1 col-md-1 text-center"><strong>{cartData.product_cost}$</strong></td>
            <td className="col-sm-1 col-md-1 text-center"><strong>{total}$</strong></td>
            <td className="col-sm-1 col-md-1">
                <button type="button" onClick={() => cartDelete(cartData.id)} className="btn btn-sm btn-danger"><i className="fa fa-trash"></i></button>
            </td>
        </tr >
    );
}

class Cart extends Component {
    constructor(props) {
        super(props);
        this.props = props;
        this.deletecart = this.deletecart.bind(this);
        this.changeQuantity = this.changeQuantity.bind(this);
        this.state = {
            total: 0,
          };
    }
    deletecart(productId) {
        this.props.removeFromCart(productId);
    }

    changeQuantity(cartData, quantity) {
        // console.log(cartData);
        if (quantity == 0) {
            this.props.removeFromCart(cartData.id);
        } else {
            this.props.updateCart(cartData, quantity, this.props.loginDetails.userId);
        }
    }

    componentWillMount() {
        // console.log(this.props.loginDetails.id);
        this.props.getCart(this.props.loginDetails.id, this.props.loginDetails.userId)
    }

    componentWillReceiveProps(newProps) {
        if (this.props.cartChange !== newProps.cartChange) {
            newProps.getCart(this.props.loginDetails.id, this.props.loginDetails.userId);
        }
    }
    
    render() {
        var styling = {
            height: "200px",
            width: "200px !important"
        };
        let price=0;
        return (
            <div className="container">
                <div className="row">
                    <hr />
                    <div className="col-md-8">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th className="text-center">Quantity</th>
                                    <th className="text-center">Price</th>
                                    <th className="text-center">Total</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.props.cartDetails.map((item, index) => <CartProducts key={index} cartData={item} cartDelete={this.deletecart} quantityChange={this.changeQuantity} />)}
                            </tbody>
                        </table>
                    </div>

                    {this.props.cartDetails.map((item, index)=> price=price+(item.product_cost*item.productqty))}
                    <div className="col-md-4">
                        <div className="panel panel-default">
                            <div className="panel-heading text-center panel-heading-custom">
                                <h4>Review Order</h4>
                            </div>
                            <div className="panel-body">
                                <div className="col-md-12">
                                    <strong>Subtotal (# items 3)</strong>
                                    <div className="pull-right"><span>{price}</span></div>
                                    <hr />
                                </div>
                                <div className="col-md-12">
                                    <strong>GST(5%)</strong>
                                    <div className="pull-right"><span>{5/100*price}</span></div>
                                    <hr />
                                </div>
                                <div className="col-md-12">
                                    <strong>Order Total</strong>
                                    <div className="pull-right"><span>{price+(5/100*price)}</span></div>
                                    <hr />
                                </div>
                            </div>
                            <div className="panel-footer">
                                <Link to= "/checkout"type="button" className="btn btn-primary btn-lg btn-block">Checkout</Link>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

Cart.propTypes = {
    //   getUserAddresses: PropTypes.func.isRequired,
    loginDetails: PropTypes.object.isRequired,
    //  userAddress: PropTypes.array.isRequired,
    //  deletedAddress: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
    return {
        loginDetails: state.applicationList.get("loginDetails"),
        cartDetails: state.applicationList.get("cartDetails"),
        cartChange: state.applicationList.get("cartChange"),
        // deletedAddress: state.applicationList.get("deletedAddress"),
    };
};

const mapDispatchToProps = dispatch => ({
    getCart: (accessToken, userId) => dispatch(getCart(accessToken, userId)),
    removeFromCart: (productId) => dispatch(removeFromCart(productId)),
    updateCart: (cartData, quantity, userId) => dispatch(updateCart(cartData, quantity, userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Cart);