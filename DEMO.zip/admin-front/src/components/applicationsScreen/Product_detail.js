import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
    getProduct,
    productToCart,
    updateProductRating
} from "./actions";

const ProductOperation = ({ data, addTOCart, openRateModal }) => {
    return (
        <div>
            <button className="btn btn-primary" onClick={() => addTOCart(data)} type="button">ADD TO CART</button>
            <button type="button" className="btn btn-warning" onClick={() => openRateModal()} data-toggle="modal" data-target=".bs-example-modal-sm">RATE PRODUCT</button>
        </div>
    );
}

const OpenModal = ({ rating, closeRatingModal, changeRating, ratingUpdate, productId }) => {
    var rates = rating - 1;
    var star = 5;
    return (
        <div class="modal fade bs-example-modal-sm in" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" style={{ display: "block", paddingRight: 14 }}>
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="text-warning text-center">
                            {/* {count_star} */}
                            {
                                new Array(star).fill(0).map((zero, index) =>
                                    (index <= rates) ?
                                        <i className="fa fa-lg fa-star" onClick={() => changeRating(index + 1)}></i> :
                                        <i className="fa fa-lg fa-star-o" onClick={() => changeRating(index + 1)}></i>
                                )}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" onClick={() => closeRatingModal()} class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="button" onClick={() => ratingUpdate()} class="btn btn-primary">RATE IT</button>
                    </div>
                </div>
            </div>
        </div>

    );
}

class Product_details extends Component {
    constructor(props) {
        super(props);
        this.props = props;
        this.addCart = this.addCart.bind(this);
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.ratingChange = this.ratingChange.bind(this);
        this.updateRating = this.updateRating.bind(this);
        this.state = {
            open_modal: false,
            rating: 0,
        };
    }

    addCart(productDetails) {
        if (this.props.loginDetails.userId) {
            let cartDetails = {
                "userId": this.props.loginDetails.userId,
                "productid": productDetails.id,
                "product_cost": productDetails.product_cost,
                "product_description": productDetails.product_description,
                "createdate": productDetails.product_created_date,
            };
            // console.log(cartDetails);
            this.props.productToCart(cartDetails);
        } else {
            alert('Please Login');
        }
    }

    openModal() {
        this.setState({
            open_modal: true
        })
    }

    closeModal() {
        this.setState({
            open_modal: false
        })
    }

    ratingChange(count) {
        console.log(count);
        this.setState({
            rating: count
        })
    }

    updateRating() {
        if (this.props.loginDetails.userId) {
            this.setState({
                open_modal: false
            });
            this.props.updateProductRating(this.props.id.location.state.productId, this.state.rating, this.props.loginDetails.id, this.props.loginDetails.userId)
        } else {
            alert('PLease login');
        }

    }
    componentWillMount() {
        this.props.getProduct(this.props.id.location.state.productId);
    }

    componentWillReceiveProps(newProps) {
        if (this.props.updateProductRating !== newProps.updateProductRating) {
            this.props.getProduct(this.props.id.location.state.productId);
        }
    }
    render() {
        var star = this.props.productDetails.product_avg_rating;
        let count_star = [];
        for (var i = 1; i <= 5; i++) {
            if (i <= star) {
                count_star.push(<i className="fa fa-lg fa-star"></i>);
            } else {
                count_star.push(<i className="fa fa-lg fa-star-o"></i>);
            }
        }
        var colour = "#FFFFFF";
        { this.props.productDetails.product_color ? colour = this.props.productDetails.product_color.color_code : '' };
        return (
            <div className="container">
                <div className="card">
                    <div className="row">
                        <div className="wrapper">
                            <div className="col-md-6">
                                <div className="preview">
                                    <div className="preview-pic tab-content">
                                        <div className="my-img active"><img className="actual-img" src={this.props.productDetails.images ? this.props.productDetails.images[0].ImgURL : ""} /></div>
                                    </div>
                                    <ul className="preview-thumbnail nav nav-tabs">
                                        <li>
                                            <div className="my-img-thumb"><img src={this.props.productDetails.images ? this.props.productDetails.images[0].ThumbURL100 : ""} /></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-md-6 ">
                                <div className="details">
                                    <h3 className="text-danger">{this.props.productDetails.product_name}</h3>

                                    <div className="text-warning">
                                        {count_star}
                                    </div>

                                    <hr />
                                    <h4>Price: <span className="text-success">{this.props.productDetails.product_cost}$</span></h4>

                                    <h4>Color:
                <span className="color" style={{ background: colour }}></span>
                                    </h4>

                                    <div className="action">
                                        <h4>Share on
                  <i className="fa fa-share-alt fa-lg"></i>
                                        </h4>
                                        <div className="share-container">
                                            <a href="#" className="btn btn-primary"><i className="fa fa-lg fa-facebook"></i></a>&nbsp;
                  <a href="#" className="btn btn-danger"><i className="fa fa-lg fa-google"></i></a>&nbsp;
                  <a href="#" className="btn btn-info"><i className="fa fa-lg fa-twitter"></i></a>&nbsp;
                  <a href="#" className="btn btn-primary"><i className="fa fa-lg fa-linkedin"></i></a>&nbsp;
                  <a href="#" className="btn btn-success"><i className="fa fa-lg fa-whatsapp"></i></a>
                                        </div>
                                    </div>

                                    <div className="action">
                                        <ProductOperation data={this.props.productDetails} addTOCart={this.addCart} openRateModal={this.openModal} />
                                        {this.state.open_modal ? <OpenModal rating={this.state.rating} closeRatingModal={this.closeModal} changeRating={this.ratingChange} ratingUpdate={this.updateRating} productId={this.props.productDetails.id}/> : ""}

                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr />
                        <div className="wrapper">
                            <div className="col-md-12">
                                <div className="preview">
                                    <div>

                                        <ul className="nav nav-tabs" role="tablist">
                                            <li role="presentation" className="active">Description</li>
                                        </ul>
                                        <br />

                                        <div className="tab-content">
                                            <div role="tabpanel" className="tab-pane active" id="tab1">{this.props.productDetails.product_description}</div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

Product_details.propTypes = {
    getProduct: PropTypes.func.isRequired,
    updateProductRating: PropTypes.func.isRequired,
    loginDetails: PropTypes.object.isRequired,
    productDetails: PropTypes.object.isRequired,
    cartAddMessage: PropTypes.object.isRequired,
    ratingUpdated: PropTypes.bool.isRequired
};

const mapStateToProps = state => {
    return {
        loginDetails: state.applicationList.get("loginDetails"),
        productDetails: state.applicationList.get("productDetails"),
        cartAddMessage: state.applicationList.get("cartAddMessage"),
        ratingUpdated: state.applicationList.get("ratingUpdated"),
    };
};

const mapDispatchToProps = dispatch => ({
    getProduct: (productId) => dispatch(getProduct(productId)),
    productToCart: (cartDetails) => dispatch(productToCart(cartDetails)),
    updateProductRating: (productId, rating, accessToken, userId) => dispatch(updateProductRating(productId, rating, accessToken, userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Product_details);