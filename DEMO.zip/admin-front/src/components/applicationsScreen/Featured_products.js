import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link,Redirect } from 'react-router-dom';
// import Banner from './Banner';
const Products = (productDetails) => {
  var star =productDetails.productDetails.product_avg_rating;
  let count_star =[];
  for(var i=1;i<=5;i++){
    if(i<=star){
    count_star.push(<i className="fa fa-lg fa-star"></i>);
    } else {
      count_star.push(<i className="fa fa-lg fa-star-o"></i>);
   }
  }
  return (
        <div className="thumbnail">
          <div className="img-thumb">
            <img src={productDetails.productDetails.images[0].ImgURL} className="img img-responsive" />
          </div>
          <div className="caption">
            <h4 className="text-center"><Link to={{ pathname: '/product_detail', state: { productId: productDetails.productDetails.id} }}>{productDetails.productDetails.product_name}</Link></h4>
            <h4 className="text-center">{productDetails.productDetails.product_cost}</h4>
            <div className="text-center">
            {count_star}
            </div>
          </div>
        </div>
  );
};

const Banner = ({banner,count}) =>{
  if(count ==1){
      return(
              <div className="item active">
              <img className="slide-image" src={banner.ImgURL} alt="" />
              <div className="carousel-caption">
              </div>
            </div>
    );
  } else {
    return(
            <div className="item">
              <img className="slide-image" src={banner.ImgURL} alt="" />
              <div className="carousel-caption">
              </div>
            </div>
        );
  }
};

Products.propTypes = {
  // campaign: PropTypes.object.isRequired,
  // classes: PropTypes.object.isRequired,
  // deleteHandler: PropTypes.func.isRequired,
  // enableOrDisableHandler: PropTypes.func.isRequired,
};

const Featured_products = (data) => {  
		return (
  <div className="container">
      <div className="row">
      <div className="carousel-holder">
        <div  id="carousel-example-generic" className="carousel slide" data-ride="carousel">
          <ol className="carousel-indicators" >
            <li data-target="#carousel-example-generic" data-slide-to="0" className="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="i"></li>
          </ol>
          <div className="carousel-inner" role="listbox">
          {data.banner.map((item,index) => <Banner count={index} banner={item} />)}
          </div>
          <a className="left carousel-control" href="#carousel-example-generic" data-slide="prev">
            <span className="glyphicon glyphicon-chevron-left"></span>
          </a>
          <a className="right carousel-control" href="#carousel-example-generic" data-slide="next">
            <span className="glyphicon glyphicon-chevron-right"></span>
          </a>
        </div>
      </div>
    </div>
    <h3 className="text-center">Popular Products <small><Link to="/view_allproducts">--view all</Link></small></h3> 
    
    
    <div className="row">
    {data.data.map((item,index) => <div className="col-md-4" key={index} ><Products key={index} productDetails={item} /></div>)}
    </div>
  </div>
	);
 }
export default Featured_products;