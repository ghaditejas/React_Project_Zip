import ActionTypes from './actionTypes';
import applicationService from '../../services/applicationService';
/*
*It gets the response from api and processes it
*@param- response
*/
export const applicationResponse = (response) => {
  let data = response.map(item => item.id);
  return { type: ActionTypes.APPLICATIONLIST_RESPONSE, payload: response }

};

/**
*It fires an api for getting application
*
*/
export const applicationRequest = () => async (dispatch) => {
  const applicationRes = await applicationService.getapplication();
  dispatch(applicationResponse(applicationRes));
};

export const loginResponse = (response) => {
  return { type: ActionTypes.LOGIN_RESPONSE, payload: response }
};

export const loggin = (email, password) =>async (dispatch) => {
  const loginRes = await applicationService.loginProcess(email, password);
  dispatch(loginResponse(loginRes));
};

export const logout = () =>{
  return { type: ActionTypes.LOGOUT_RESPONSE}
}

export const userDataResponse = (response) => {
  return { type: ActionTypes.USERDATA_RESPONSE, payload: response }
};

export const getUserData = (accessToken,userId) => async (dispatch) => {
  const userDataRes = await applicationService.getUserDataProcess(accessToken,userId);
  dispatch(userDataResponse(userDataRes));
};

export const userAddressResponse = (response) => {
  return { type: ActionTypes.USERADDRESS_RESPONSE, payload: response }
};

export const getUserAddresses = (accessToken,userId) => async (dispatch) => {
  const userAddressRes = await applicationService.getUserAddressesProcess(accessToken,userId);
  dispatch(userAddressResponse(userAddressRes));
};

export const updateUserProfileResponse = (response) => {
  return { type: ActionTypes.USERPROFILEUPDATE_RESPONSE, payload: response }
};

export const updateUserProfile = (userProfile,accessToken,userId) => async (dispatch) => {
  const userProfileUpdateRes = await applicationService.updateUserProfileProcess(userProfile,accessToken,userId);
  dispatch(updateUserProfileResponse(userProfileUpdateRes));
};

export const addUserAddressResponse = (response) => {
  return { type: ActionTypes.ADD_USER_ADDRESS_RESPONSE, payload: response }
};

export const addUserAddress= (newaddress,accessToken,userId) =>async (dispatch) => {
  const addUserAddressRes = await applicationService.addUserAddressProcess(newaddress,accessToken,userId);
  dispatch(addUserAddressResponse(addUserAddressRes));
};

export const deleteAddressResponse = (response) => {
  return { type: ActionTypes.DELETE_USER_ADDRESS_RESPONSE, payload: response }
};

export const deleteUserAddress = (addressId,accessToken,userId) => async (dispatch) => {
  const deleteAddressRes = await applicationService.deleteAddressProcess(addressId,accessToken,userId);
  dispatch(deleteAddressResponse(deleteAddressRes));
};

export const getAddressResponse = (response) => {
  return { type: ActionTypes.GET_ADDRESS_RESPONSE, payload: response }
};

export const getUserAddress = (addressId, accessToken, userId) => async (dispatch) => {
  const getAddressRes = await applicationService.getAddressProcess(addressId,accessToken,userId);
  dispatch(getAddressResponse(getAddressRes));
};

export const editAddressResponse = (response) => {
  return { type: ActionTypes.EDIT_ADDRESS_RESPONSE, payload: response }
};

export const editUserAddress = (editAddress, accessToken, addressId) => async (dispatch) => {
  const editAddressRes = await applicationService.editAddressProcess(editAddress,accessToken,addressId);
  dispatch(editAddressResponse(editAddressRes));
};

export const bannerResponse = (response) => {
  return { type: ActionTypes.BANNERLIST_RESPONSE, payload: response }
};

export const bannerRequest = () => async (dispatch) => {
  const bannerRes = await applicationService.getbanner();
  dispatch(bannerResponse(bannerRes));
}

export const getAllProductsResponse = (response) => {
  return { type: ActionTypes.ALL_PRODUCTS_RESPONSE, payload: response }
};

export const getProducts =(filter) => async(dispatch) => {
  const getAllProductsRes = await applicationService.getAllProducts(filter);
  dispatch(getAllProductsResponse(getAllProductsRes));
}

export const getAllCategoriesResResponse = (response) => {
  return { type: ActionTypes.ALL_CATEGORIES_RESPONSE, payload: response }
};

export const getCategories= () => async(dispatch) => {
  const getAllCategoriesRes = await applicationService.getAllCategories();
  dispatch(getAllCategoriesResResponse(getAllCategoriesRes));
}

export const getAllColourResponse = (response) => {
  return { type: ActionTypes.ALL_COLOURS_RESPONSE, payload: response }
};

export const getColour= () => async(dispatch) => {
  const getAllColourRes = await applicationService.getAllColour();
  dispatch(getAllColourResponse(getAllColourRes));
}

export const addToCartResponse = (response) => {
  return { type: ActionTypes.ADD_TO_CART_RESPONSE, payload: response }
};

export const productToCart= (cartDetails) => async(dispatch) => {
  const addToCartRes = await applicationService.addToCart(cartDetails);
  dispatch(addToCartResponse(addToCartRes));
}

export const getCartResponse = (response) => {
  return { type: ActionTypes.CART_DETAILS_RESPONSE, payload: response }
};

export const getCart = (accessToken,userId) => async (dispatch) => {
  const getCartRes = await applicationService.getCartProcess(accessToken,userId);
  dispatch(getCartResponse(getCartRes));
};

export const removeFromCartResponse = (response) => {
  return { type: ActionTypes.DELETE_CART_PRODUCT_RESPONSE, payload: response }
};

export const removeFromCart = (productId) => async (dispatch) => {
  const removeFromCartRes = await applicationService.removeFromCartProcess(productId);
  dispatch(removeFromCartResponse(removeFromCartRes));
};

export const updateCartResponse = (response) => {
  return { type: ActionTypes.UPDATE_CART_PRODUCT_RESPONSE, payload: response }
};

export const updateCart = (cartData,quantity,userId) => async (dispatch) => {
  const updateCartRes = await applicationService.updateCartProcess(cartData,quantity,userId);
  dispatch(updateCartResponse(updateCartRes));
};

export const makeOrderResponse = (response) => {
  return { type: ActionTypes.MAKE_ORDER_RESPONSE, payload: response }
};

export const makeOrder = (card, accessToken, userId, email, product, addressId) => async (dispatch) => {
  const makeOrderRes = await applicationService.makeOrderProcess(card, accessToken, userId, email, product, addressId);
  dispatch(makeOrderResponse(makeOrderRes));
};

export const getOrderResponse = (response) => {
  console.log(response);
  return { type: ActionTypes.GET_ORDER_RESPONSE, payload: response }
};

export const getOrder = (accessToken,userId) => async (dispatch) => {
  const getOrderRes = await applicationService.getOrderProcess(accessToken,userId);
  dispatch(getOrderResponse(getOrderRes));
};

export const getProductResponse = (response) => {
  return { type: ActionTypes.GET_PRODUCT_RESPONSE, payload: response }
};

export const getProduct = (productId) => async (dispatch) => {
  const getProductRes = await applicationService.getProductProcess(productId);
  dispatch(getProductResponse(getProductRes));
};

export const updateProductRatingResponse = (response) => {
  return { type: ActionTypes.UPDATE_RATING_RESPONSE, payload: response }
};

export const updateProductRating= (productId, rating, accessToken, userId) => async (dispatch) => {
  const updateProductRatingRes = await applicationService.updateProductRatingProcess(productId, rating, accessToken, userId);
  dispatch(updateProductRatingResponse(updateProductRatingRes));
};

export const userRegisterResponse = (response) => {
  return { type: ActionTypes.REGISTER_RESPONSE, payload: response }
};

export const userRegister = (registerDetails) =>async (dispatch) => {
  const userRegisterRes = await applicationService.userRegisterProcess(registerDetails);
  dispatch(userRegisterResponse(userRegisterRes));
};

export const contactAdminResponse = (response) => {
  console.log(response);
  return { type: ActionTypes.CONTACT_RESPONSE, payload: response }
};

export const contactAdmin = (query, accessToken, userId) =>async (dispatch) => {
  const contactAdminRes = await applicationService.contactAdminProcess(query, accessToken, userId);
  dispatch(contactAdminResponse(contactAdminRes));
};  
/*
*It gets the response from api and processes it
*@param- response
*/
export const applicationDetailResponse = (response, applicationId) => ({
  type: ActionTypes.APPLICATIONDETAIL_RESPONSE,
  payload: { response, applicationId },
});

/**
*It fires an api for getting application details 
*@param - id
*/
export const applicationDetailRequest = id => async (dispatch) => {
  const applicationDetailRes = await applicationService.getapplicationDetail(id);
  dispatch(applicationDetailResponse(applicationDetailRes, id));
};

/*
*It gets the response from api and processes it
*@param- response
*/
export const createApplicationResponse = (response) => {
  if (response.statusCode === 200) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE,
      payload: true
    }
  }

};

/**
*It fires an api for creating an application
*@param - id,name,androidCode,iosCode
*/
export const createApplicationRequest = (id, name, androidCode, iosCode) => async (dispatch) => {
  dispatch(isDeleting());
  const applicationRes = await applicationService.createApplication(id, name, androidCode, iosCode);
  dispatch(createApplicationResponse(applicationRes));
};

/**
*It used while creating or editing an application for setting the values
*@param - name,androidCode,iosCode
*/
export const setCreateAppText = (name, androidCode, iosCode) => ({
  type: ActionTypes.CREATE_APPLICATION_TEXT,
  payload: {
    name,
    androidCode,
    iosCode
  },
});

/**
*It used to open a modal
*@param - from 
*/
export const openAddModal = (from) => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_ADD_OPEN,
  payload: from,
});

/**
*It used to close a modal
*  
*/
export const closeAddModal = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE,
});

/**
*It used to open the delete modal
*  
*/
export const openDeleteModal = application => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETE_OPEN,
  payload: application,
});

/**
*It used to close the delete modal
*  
*/
export const closeDeleteModal = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETE_CLOSE,
});

/**
*It checks the status of delete functionality
*  
*/
export const isDeleting = () => ({
  type: ActionTypes.APPLICATIONLIST_MODAL_DELETING,
});

/*
*It gets the response from api and processes it
*@param- response
*/
export const deleteResponse = (res) => {
  if (res === true) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_DELETION_OK,
      payload: true,
    };
  }
  return {
    type: ActionTypes.APPLICATIONLIST_MODAL_DELETION_ERROR,
    payload: false,
  };
};

/**
*It fires an api for deleting an application
*@param - id,externalAppId
*/
export const deleteApplicationRequest = (id, externalAppId) => async (dispatch) => {
  dispatch(isDeleting());
  const response = await applicationService.deleteApplication(id, externalAppId);
  dispatch(deleteResponse(response));
};

/*
*It is used to enable application data for checkbox select
*@param- response
*/
export const checkboxEnable = (application) => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX,
  payload: application,
});

/*
*It is used to enable all the application
*@param- response
*/
export const enableAll = (enableAll) => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_ALL,
  payload: enableAll,
});

/*
*It gets the response from api and processes it
*@param- response
*/
export const editApplicationResponse = (response) => {
  if (response.statusCode === 200) {
    return {
      type: ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE_EDIT,
      payload: true
    }
  }
};

/**
*It fires an api for editing an application
*@param - externalId,id,name,androidCode,iosCode
*/
export const editApplicationRequest = (externalId, id, name, androidCode, iosCode) => async (dispatch) => {
  dispatch(isDeleting());
  const editApplicationRes = await applicationService.editApplication(externalId, id, name, androidCode, iosCode);
  dispatch(editApplicationResponse(editApplicationRes));
};

/*
*It checks the enable application
*@param- application
*/
export const checkboxEnableApplication = (application) => ({
  type: ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX_STATUS,
  payload: application,
});