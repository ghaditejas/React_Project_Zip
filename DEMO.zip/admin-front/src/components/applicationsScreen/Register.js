import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import Button from 'react-validation/build/button';
import validator from 'validator';
import Notifications, { notify } from 'react-notify-toast';
import {
  userRegister,
} from "./actions";

const required = (value) => {
  if (!value.toString().trim().length) {
    // We can return string or jsx as the 'error' prop for the validated Component
    return (
      <span className="error" style={{ color: "red" }}>Require</span>
    );
  }
};

const email = (value) => {
  if (!validator.isEmail(value)) {
    return (
      <span className="error" style={{ color: "red" }}>{value} is not a valid email.</span>);
  }
};

class Register extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    this.state = {
      "first_name": "",
      "last_name": "",
      "gender": "",
      "email": "",
      "password": "",
      "phone_no": 0,
      "username": "",
      "role": "AppUser",
      "orderId": "",
      "shoppingcartId": "",
      "is_active": true,
      "birth_of_date": 0,
      "pass": "",
      "checkpass": "",
      "redirect": false
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({ [key]: value })
    if (this.state.pass == this.state.checkpass) {
      this.setState({
        "password": this.state.pass
      })
    }
  }

  handleSubmit(event) {
    if (this.state.password) {
      this.props.userRegister(this.state);
      event.preventDefault();
      this.setState({
        "redirect": true
      });
    } else {
      let myColor = { background: 'REd', text: "#FFFFFF" };
      notify.show("Password dont match", 'error', 1000, myColor);
    }
  }
  render() {
    return (
      <div className="container">
        {this.state.redirect ? <Redirect to='/Login' /> : ''}
        <Notifications />
        <div className="container-register">
          <div className="col-md-5">
            <div className="panel panel-default">
              <div className="panel-heading">
                <h2 className="text-center text-muted">Register to NeoSTORE</h2>
              </div>
              <div className="panel-body">
                <p className="text-muted text-center">EASILY USING</p>
                <button className="btn btn-default btn-lg">
                  <i className="fa fa-facebook fa-lg  text-primary" ></i>
                  Facebook
            </button>
                <button className="btn btn-default btn-lg pull-right">
                  <i className="fa fa-google fa-lg text-danger"></i>
                  Google
            </button>

                <p className="text-muted text-center">--OR USING--</p>

                <Form className="form-custom">
                  <div className="form-group">
                    <Input type="email" className="form-control" name="email" onChange={this.handleChange} validations={[required, email]} placeholder="Your Email Address" />
                    <br />
                    <Input type="password" className="form-control" name="pass" onChange={this.handleChange} validations={[required]} placeholder="Choose Password" />
                    <br />
                    <Input type="password" className="form-control" name="checkpass" onChange={this.handleChange} validations={[required]} placeholder="Confirm Password" />
                    <br />
                    <Input type="number" name="phone_no" className="form-control" onChange={this.handleChange} validations={[required]} placeholder="Enter Phone Number" />
                    <br />
                    <legend className="gender-legend">I'm</legend>
                    <div className="checkbox">
                      <label><input type="radio" onChange={this.handleChange} value="male" name="gender" /> <strong>Male</strong> </label>
                      <label><input type="radio" onChange={this.handleChange} value="female" name="gender" /> <strong>Female</strong> </label>
                    </div>
                    <Button type="button" onClick={this.handleSubmit} className="btn btn-lg btn-primary btn-block">Register</Button>
                  </div>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Register.propTypes = {
  userRegister: PropTypes.func.isRequired,
  registered: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  return {
    registered: state.applicationList.get("registered"),
  };
};

const mapDispatchToProps = dispatch => ({
  userRegister: (registerDetails) => dispatch(userRegister(registerDetails)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);