import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
  getOrder,
} from "./actions";

const OrderList =({data}) => {
  var date_order =data.order.createon;
    var order_date = date_order.split('T')[0];
  console.log(data);
  return (
    <div className="panel panel-default">
            <div className="panel-heading text-muted">
              <span className="text-warning"><strong>{data.order.orderstatus}</strong></span>
              <span>Order No: {data.order.id}</span>
              <div>
                <small>Placed on {order_date} </small>
                <small className="text-success"><strong> / {data.order.ordertotal}$</strong></small>
              </div>
              <hr />
            </div>
            <div className="panel-body">
              <div className="row">
                {data.products.map((item,id)=><div className="col-md-3">
                  <div className="thumbnail">
                    <img src={item.images.ThumbURL100} alt="product_image" className="img-rounded" />
                  </div>
                </div>)}
              </div>
            </div>
            <div className="panel-footer">
              <button type="button" className="btn btn-success">Download invoice as PDF</button>
            </div>
          </div>
  );
}

class Orders extends Component{

  componentWillMount(){
    // console.log(this.props.loginDetails.id);
    this.props.getOrder(this.props.loginDetails.id,this.props.loginDetails.userId)
  }

  render(){
    var  styling = {
          height: "200px",
          width: "200px !important"
        };
    return (
      <div className="container">
    <div className="container">
      <div className="container-fluid">
        <div className="col-md-12">
          <h4> My Account </h4>
          <hr />
        </div>

        <Side_menu />

        <div className="col-md-9">
        {this.props.orderDetails.map((item,id)=><OrderList key={id} data={item}/>) }
          
        </div>
      </div>
    </div>
  </div>

      );
  }
}

Orders.propTypes = {
  getOrder: PropTypes.func.isRequired,
 loginDetails: PropTypes.object.isRequired,
 orderDetails: PropTypes.array.isRequired,
};

const mapStateToProps = state => {
 return {
    loginDetails: state.applicationList.get("loginDetails"),
    orderDetails: state.applicationList.get("orderDetails"),
 };
};

const mapDispatchToProps = dispatch => ({
  getOrder: (accessToken,userId) => dispatch(getOrder(accessToken,userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Orders);