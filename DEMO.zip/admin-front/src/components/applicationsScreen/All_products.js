import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import Notifications, {notify} from 'react-notify-toast';
import {
    getProducts,
    getCategories,
    getColour,
    productToCart,
} from "./actions";

const ALLProducts = ({ productDetails, addTOCart }) => {
    var star = productDetails.product_avg_rating;
    let count_star = [];
    for (var i = 1; i <= 5; i++) {
        if (i <= star) {
            count_star.push(<i className="fa fa-lg fa-star"></i>);
        } else {
            count_star.push(<i className="fa fa-lg fa-star-o"></i>);
        }
    }
    return (
        <div className="thumbnail">
            <div className="image-thumb">
                <img className="image" src={productDetails.images[0].ThumbURL250} alt="product_image" />
            </div>
            <div className="caption">
                <p className="elipse-product"><a href="./product-details.html">{productDetails.product_name}</a></p>
                <button onClick={() => addTOCart(productDetails)} className="pull-right btn btn-danger btn-xs">Add To Cart</button>
                <p><strong>{productDetails.product_cost}</strong></p>
                <fieldset className="rating">
                    <div className="text-warning text-center">
                        {count_star}
                    </div>
                </fieldset>
            </div>
        </div>
    );
}

const AllCategoires = ({ categoryDetails, filters }) => {
    let value = {
        "categoryId": categoryDetails.id
    }
    return (
        <li className="list-group-item" onClick={() => filters('where', value)}>
            <a><i className="fa fa-dot-circle-o"></i> {categoryDetails.category_name}</a>
        </li>
    );
}

const AllColours = ({ colourDetails, filters }) => {
    let value = {
        "product_color.color_name": { "like": colourDetails.color_name, "options": "i" }
    }
    return (
        <li onClick={() => filters('where', value)}><button type="button" data-toggle="tooltip" data-placement="top" title="color" className="color-box" style={{ background: colourDetails.color_code }}></button></li>
    );
}

class All_products extends Component {
    constructor(props) {
        super(props);
        this.props = props;
        this.filter = this.filter.bind(this);
        this.addCart = this.addCart.bind(this);
        this.state = {
            "where": {},
            "order": "",
            "include": "images"
        };
    }

    filter(key, value) {
        this.setState({ [key]: value }, () => this.props.getProducts(this.state));
    }

    addCart(productDetails) {
        if (this.props.loginDetails.userId) {
            let myColor = { background: '#0E1717', text: "#FFFFFF" };
            notify.show('Product Added to cart','success',1000,myColor);
            let cartDetails = {
                "userId": this.props.loginDetails.userId,
                "productid": productDetails.id,
                "product_cost": productDetails.product_cost,
                "product_description": productDetails.product_description,
                "createdate": productDetails.product_created_date,
            };
            // console.log(cartDetails);
            this.props.productToCart(cartDetails);
        } else {
            alert('Please Login');
        }
    }

    componentWillMount() {
        this.props.getProducts(this.state);
        this.props.getCategories();
        this.props.getColour();
    }
    render() {
        var styling = {
            height: "200px",
            width: "200px !important"
        };
        return (
            <div className="container">
            <Notifications />
                <div className="col-md-3">
                    <div className="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                        <div className="panel panel-danger">
                            <div className="panel-heading" role="tab" id="headingOne">
                                <h4 className="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#categories">
                                        <i className="fa fa-lg fa-angle-double-down"></i> Categories
                      </a>
                                </h4>
                            </div>
                            <div id="categories" className="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                {this.props.allCategories.map((item, index) => <div className="list-group" key={index} ><AllCategoires key={index} categoryDetails={item} filters={this.filter} /></div>)}
                            </div>

                        </div>

                        <div className="panel panel-danger">
                            <div className="panel-heading" role="tab" id="headingOne">
                                <h4 className="panel-title">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#colors">
                                        <i className="fa fa-lg fa-angle-double-down"></i> Colors
                      </a>
                                </h4>
                            </div>
                            <div id="colors" className="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                <div className="list-group-item">

                                    <ul className="list-inline">
                                        {this.props.allColour.map((item, index) => <AllColours key={index} colourDetails={item} filters={this.filter} />)}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-md-9 vertical-line">
                    <div className="row padding-row">
                        <h5 className="pull-left">Filters</h5>
                        <div className="pull-right">
                            <ul className="nav nav-pills" role="tablist">
                                <li className="nav-item" onClick={() => this.filter('order', 'product_avg_rating DESC')}>
                                    <a className="nav-link" href="javascript:void(0)" aria-controls="tab1" role="tab" data-toggle="tab">
                                        <i className="fa fa-star" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="nav-item" onClick={() => this.filter('order', 'product_cost DESC')}>
                                    <a className="nav-link" href="javascript:void(0)" aria-controls="tab2" role="tab" data-toggle="tab">
                                        <i className="fa fa-inr" aria-hidden="true"></i>
                                        <i className="fa fa-arrow-up" aria-hidden="true"></i>
                                    </a>
                                </li>
                                <li className="nav-item" onClick={() => this.filter('order', 'product_cost ASC')}>
                                    <a className="nav-link" href="javascript:void(0)" aria-controls="tab3" role="tab" data-toggle="tab">
                                        <i className="fa fa-inr" aria-hidden="true"></i>
                                        <i className="fa fa-arrow-down" aria-hidden="true"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <h5 className="pull-right">Sort By : </h5>
                    </div>
                    <br />
                    {this.props.allProducts.map((item, index) => <div className="col-md-4" key={index} ><ALLProducts key={index} productDetails={item} addTOCart={this.addCart} /></div>)}
                </div>
                {/* <NotificationContainer /> */}
            </div>
        );
    }
}

All_products.propTypes = {
    getProducts: PropTypes.func.isRequired,
    getCategories: PropTypes.func.isRequired,
    // getColour: PropTypes.func.isRequired,
    loginDetails: PropTypes.object.isRequired,
    allProducts: PropTypes.array.isRequired,
    allCategories: PropTypes.array.isRequired,
    allColour: PropTypes.array.isRequired,
    cartAddMessage: PropTypes.object.isRequired
    // deletedAddress: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
    return {
        loginDetails: state.applicationList.get("loginDetails"),
        allProducts: state.applicationList.get("allProducts"),
        allCategories: state.applicationList.get("allCategories"),
        allColour: state.applicationList.get("allColour"),
        cartAddMessage: state.applicationList.get("cartAddMessage"),
    };
};

const mapDispatchToProps = dispatch => ({
    getProducts: (filter) => dispatch(getProducts(filter)),
    getCategories: () => dispatch(getCategories()),
    getColour: () => dispatch(getColour()),
    productToCart: (cartDetails) => dispatch(productToCart(cartDetails)),
});

export default connect(mapStateToProps, mapDispatchToProps)(All_products);