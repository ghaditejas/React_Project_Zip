import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import ReactDOM from 'react-dom';

class Thankyou extends Component {
    constructor(props) {
        super(props);
        this.props = props;
    }
    render() {
        return (
            <div>
                <div className="jumbotron text-center">
                    <h1 className="display-3">Thank You!</h1>
                    <p className="lead">
                        <strong>Please check your
                     <Link to="/Orders">Orders</Link>
                        </strong> for more details.
                    </p>
                    <hr />
                    <p>Having trouble?<Link to="/Contact">Contact us</Link></p>
                    <p className="lead" >
                        <Link to="/" className="btn btn-primary btn-sm" type="button">Continue to homepage</Link>
                    </p>
                </div>
            </div>
        );
    }
}

export default Thankyou;