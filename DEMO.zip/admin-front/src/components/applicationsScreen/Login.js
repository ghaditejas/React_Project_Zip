import { connect } from "react-redux";
import PropTypes from "prop-types";
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import React, { Component } from 'react';

import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import Button from 'react-validation/build/button';
import validator from 'validator';
// import ValidateableForm from 'react-form-validate';
import {
  applicationRequest,
  bannerRequest,
  loggin,
  openDeleteModal,
  closeDeleteModal,
  openAddModal,
  deleteApplicationRequest,
  applicationDetailRequest,
  closeAddModal,
  createApplicationRequest,
  setCreateAppText,
  checkboxEnable,
  editApplicationRequest,
  enableAll,
  checkboxEnableApplication,
} from "./actions";

const required = (value) => {
  if (!value.toString().trim().length) {
    // We can return string or jsx as the 'error' prop for the validated Component
    return(
        <span className="error" style={{color:"red"}}>Require</span>
    );
  }
};
 
const email = (value) => {
  if (!validator.isEmail(value)) {
    return (
      <span className="error" style={{color:"red"}}>{value} is not a valid email.</span>);
  }
};

class Login extends Component {
  constructor(props) {
    super(props);
    this.props = props;

    this.state = {
      email: "",
      password: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }
  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({ [key]: value })
  }

  handleSubmit(event) {
    // alert('Submitted Data : ' + JSON.stringify(this.state));
    this.props.loggin(this.state.email, this.state.password);
    event.preventDefault();
  }

  render() {
    return (
      <div>
        <div className="container">
          <div className="container-login">
            <div className="col-md-5">
              <div className="panel panel-default">
                <div className="panel-heading">
                  <h2 className="text-center text-muted">Login to NeoSTORE</h2>
                </div>
                <div className="panel-body">
                  <p className="text-muted text-center">EASILY USING</p>
                  <button className="btn btn-default btn-lg"><i className="fa fa-facebook fa-lg  text-primary" ></i>Facebook</button>
                  <button className="btn btn-default btn-lg pull-right"><i className="fa fa-google fa-lg text-danger"></i>Google</button>

                  <p className="text-muted text-center">--OR USING--</p>
                  <Form className="form-custom">
                    <div className="form-group">
                      <Input type="email" name="email" className="form-control" onChange={this.handleChange} placeholder="Email Address" validations={[required, email]} />
                      <br />
                      <Input type="password" name="password" className="form-control" onChange={this.handleChange} placeholder="Password" validations={[required]} />
                      <br />
                    </div>
                    <div className="form-group">
                      <Button className="btn btn-lg btn-primary btn-block" type="button" onClick={this.handleSubmit}>Login</Button>
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    );
  }

}

Login.propTypes = {
  loggin: PropTypes.func.isRequired,
  logged: PropTypes.bool.isRequired,
  loginDetails: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
  return {
    logged: state.applicationList.get("logged"),
    loginDetails: state.applicationList.get("loginDetails"),
  };
};

const mapDispatchToProps = dispatch => ({
  loggin: (email, password) => dispatch(loggin(email, password)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
