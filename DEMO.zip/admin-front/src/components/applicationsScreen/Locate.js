import React, { Component } from 'react';

class Locate extends Component{
	render(){
    var location ='./css/staticmap.png';
		return (
			<div>

  <div className="container">
    <div className="panel panel-default">
      <div className="panel-heading">Locate Us</div>
      <div className="panel-body">
          <img className="img-responsive" width="930" src={location} alt="Google Map of It Sigma park" />
      </div>
    </div>
  </div>

			</div>
			);
	}
}
export default Locate;