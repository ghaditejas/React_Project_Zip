import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
  getUserAddresses,
} from "./actions";

const Addresses = ({ data, selectAddress }) => {
  // console.log(data);
  var path = '/Address_edit/' + data.id;
  return (
    <div className="panel panel-default">
      <div className="panel-body">
        <p>{data.fulladdress}</p>
        <p>{data.city}-{data.pincode}</p>
        <p>{data.state}</p>
        <p>{data.country}</p>
      </div>
      <div className="panel-footer">
        <input name="address" type="radio" onClick={() => selectAddress(data.id)} />Select
        <Link to={{ pathname: '/Address_edit', state: { addressId: data.id } }} className="btn btn-default" type="button"><i className="fa fa-pencil"></i>Edit</Link>
      </div>
    </div>
  );
}

class Address extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    this.addressSelected = this.addressSelected.bind(this);
    this.state = {
      next_buton: false,
      address_id: "",
    }
  }
  addressSelected(addressId) {
    console.log(addressId);
    this.setState({
      next_button: true,
      address_id: addressId
    });
  }

  componentWillMount() {
    ;
    this.props.getUserAddresses(this.props.loginDetails.id, this.props.loginDetails.userId)
  }

  // componentWillReceiveProps(newProps) {
  //   if (this.props.deletedAddress !== newProps.deletedAddress) {
  //     newProps.getUserAddresses(this.props.loginDetails.id,this.props.loginDetails.userId);
  //   }
  // }
  render() {
    var styling = {
      height: "200px",
      width: "200px !important"
    };
    return (
      <div className="container">
        <div className="panel-heading">
          <h3>Select delivery address</h3>
          <hr />
        </div>
        <div className="panel-body">
          {this.props.userAddress.map((item, id) => <Addresses key={id} data={item} selectAddress={this.addressSelected} />)}
        </div>
        <div className="panel-footer">
          <hr />
          {this.state.address_id}
          {this.state.next_button? 
          <Link to={{ pathname: '/payment', state:{ addressId: this.state.address_id}}} type="button" className="btn btn-default btn-lg">
          Next <i className="fa fa-angle-double-right"></i>
        </Link>:
          <button disabled="true" type="button" className="btn btn-default btn-lg">
            Next <i className="fa fa-angle-double-right"></i>
          </button>
          }
          <Link to="/Address_add" type="button"  className="btn btn-default btn-lg">Add new</Link>
        </div>
      </div>

    );
  }
}

Address.propTypes = {
  getUserAddresses: PropTypes.func.isRequired,
  loginDetails: PropTypes.object.isRequired,
  userAddress: PropTypes.array.isRequired,
};

const mapStateToProps = state => {
  return {
    loginDetails: state.applicationList.get("loginDetails"),
    userAddress: state.applicationList.get("userAddress"),
  };
};

const mapDispatchToProps = dispatch => ({
  getUserAddresses: (accessToken, userId) => dispatch(getUserAddresses(accessToken, userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Address);