import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
  applicationRequest,
  bannerRequest,
  loggin,
  getUserData,
  getUserAddresses,
  deleteUserAddress,
} from "./actions";

const Addresses = ({ data, addressdelete }) => {
  // console.log(data);
  var path = '/Address_edit/' + data.id;
  return (
    <div className="panel panel-default">
      <div className="panel-body">
        <p>{data.fulladdress}</p>
        <p>{data.city}-{data.pincode}</p>
        <p>{data.state}</p>
        <p>{data.country}</p>
      </div>
      <div className="panel-footer">
        <Link to={{ pathname: '/Address_edit', state: { addressId: data.id } }} className="btn btn-default" type="button"><i className="fa fa-pencil"></i>Edit</Link>
        <button className="btn btn-default" onClick={() => addressdelete(data.id)} type="button"><i className="fa fa-remove"></i>Remove</button>
      </div>
    </div>
  );
}

class Address extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    this.deleteaddress = this.deleteaddress.bind(this);
  }
  deleteaddress(addressId) {
    this.props.deleteUserAddress(addressId, this.props.loginDetails.id, this.props.loginDetails.userId);
  }

  componentWillMount() {
    // console.log(this.props.loginDetails.id);
    this.props.getUserAddresses(this.props.loginDetails.id, this.props.loginDetails.userId)
  }

  componentWillReceiveProps(newProps) {
    if (this.props.deletedAddress !== newProps.deletedAddress) {
      newProps.getUserAddresses(this.props.loginDetails.id, this.props.loginDetails.userId);
    }
  }
  render() {
    var styling = {
      height: "200px",
      width: "200px !important"
    };
    return (
      <div className="container">
        <div className="container">
          <div className="container-fluid">
            <div className="col-md-12">
              <h4> My Account </h4>
              <hr />
            </div>

            <Side_menu />

            <div className="col-md-9">
              <div className="panel panel-default">
                <div className="panel-heading">
                  <h3>Addresses</h3>
                  <hr />
                </div>
                <div className="panel-body">
                  {this.props.userAddress.map((item, id) => <Addresses key={id} data={item} addressdelete={this.deleteaddress} />)}
                </div>
                <div className="panel-footer">
                  <hr />
                  <Link to="/Address_add" type="button" className="btn btn-default btn-lg">Add new</Link>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

    );
  }
}

Address.propTypes = {
  getUserAddresses: PropTypes.func.isRequired,
  loginDetails: PropTypes.object.isRequired,
  userAddress: PropTypes.array.isRequired,
  deletedAddress: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  return {
    loginDetails: state.applicationList.get("loginDetails"),
    userAddress: state.applicationList.get("userAddress"),
    deletedAddress: state.applicationList.get("deletedAddress"),
  };
};

const mapDispatchToProps = dispatch => ({
  getUserAddresses: (accessToken, userId) => dispatch(getUserAddresses(accessToken, userId)),
  deleteUserAddress: (addressId, accessToken, userId) => dispatch(deleteUserAddress(addressId, accessToken, userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Address);