import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import Textarea from 'react-validation/build/textarea';
import Button from 'react-validation/build/button';
import validator from 'validator';
import Notifications, {notify} from 'react-notify-toast';
import {
  contactAdmin,
} from "./actions";

const required = (value) => {
  if (!value.toString().trim().length) {
    // We can return string or jsx as the 'error' prop for the validated Component
    return (
      <span className="error" style={{ color: "red" }}>Require</span>
    );
  }
};


class Contact extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    this.state = {
      name: "",
      subject: "",
      message: "",
      mobile: "",
      email: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({ [key]: value })
  }

  handleSubmit(event) {
    this.props.contactAdmin(this.state, this.props.loginDetails.id, this.props.loginDetails.userId);
    event.preventDefault();
  }
  render() {
    return (
      <div>
        <div className="container">
        <Notifications />
          <div className="jumbotron">
            <div className="container">
              <div className="col-md-6">
                <Form role="form">
                  <h3>Contact Form</h3>
                  <div className="form-group">
                    <Input type="text" className="form-control" onChange={this.handleChange} id="name" name="name" placeholder="Name" validations={[required]} />
                  </div>
                  <div className="form-group">
                    <Input type="text" className="form-control" onChange={this.handleChange} id="email" name="email" placeholder="Email" validations={[required]} />
                  </div>
                  <div className="form-group">
                    <Input type="text" className="form-control" onChange={this.handleChange} id="mobile" name="mobile" placeholder="Mobile Number" validations={[required]} />
                  </div>
                  <div className="form-group">
                    <Input type="text" className="form-control" onChange={this.handleChange} id="subject" name="subject" placeholder="Subject" validations={[required]} />
                  </div>
                  <div className="form-group">
                    <Textarea className="form-control" type="textarea" onChange={this.handleChange} id="message" name="message" placeholder="Message" maxLength="140" rows="7" validations={[required]} ></Textarea>
                  </div>

                  <Button type="button" id="submit" name="submit" onClick={this.handleSubmit} className="btn btn-primary pull-right">Submit Form</Button>
                </Form>
              </div>
            </div>
          </div>

        </div>

      </div>
    );
  }
}

Contact.propTypes = {
  contactAdmin: PropTypes.func.isRequired,
  loginDetails: PropTypes.object.isRequired,
  userData: PropTypes.object.isRequired,
  contactMailSend: PropTypes.bool.isRequired
};

const mapStateToProps = state => {
  return {
    loginDetails: state.applicationList.get("loginDetails"),
    userData: state.applicationList.get("userData"),
    contactMailSend: state.applicationList.get("contactMailSend"), 
  };
};

const mapDispatchToProps = dispatch => ({
  contactAdmin: (query, accessToken, userId) => dispatch(contactAdmin(query, accessToken, userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Contact);