import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { BrowserRouter as Router, Switch, Route, Link,Redirect } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import Login from './Login'; 
import Featured_products from './Featured_products';
import Profile from './Profile';
import Profile_edit from './Profile_edit';
import Address from './Address';
import Address_add from './Address_add';
import Address_edit from './Address_edit';
import Terms from './Terms';
import Guarantee from './Guarantee';
import Policy from './Policy';
import Locate from './Locate';
import Contact from './Contact';
import Orders from './Orders';
import Cart from './Cart';
import Checkout from './Checkout';
import Payment from './Payment';
import Thankyou from './Thankyou';
import Product_detail from './Product_detail';
import All_products from './All_products';
import Register from './Register';
import {
  applicationRequest,
  bannerRequest,
  login,
  logout,
  openDeleteModal,
  closeDeleteModal,
  openAddModal,
  deleteApplicationRequest,
  applicationDetailRequest,
  closeAddModal,
  createApplicationRequest,
  setCreateAppText,
  checkboxEnable,
  editApplicationRequest,
  enableAll,
  checkboxEnableApplication
} from "./actions";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.props = props;

    this.state = {
      chkAddPopup: false,
      data: this.props.applicationList,
      searchText : '',
      searchData : [],
      logged:true,
    };
  }

  componentWillMount() {
    this.props.applicationRequest();
    this.props.bannerRequest();
  }

  // componentWillReceiveProps(newProps) {
  //   // if(this.props.createApplicationStatus !== newProps.createApplicationStatus || this.props.isDeleted !== newProps.isDeleted || this.props.editApplicationStatus!== newProps.editApplicationStatus){
  //   //   this.setState({searchText:''});
  //   //   this.setState({searchData:[]});
  //   //   newProps.applicationDetail(4);
  //   // }
  // }

  render() {
    return (
       <Router>
          <div>
            {/* {this.props.location.pathname=="/cart"?"hello":"notworking"} */}
             <Header  logged={this.props.logged} logout={this.props.logout}/>
             <Switch>
             <Route exact
                path="/"
                render={(routeProps) => (
                <Featured_products  data={this.props.applicationList} banner={this.props.bannerList} />
                 )}
                />
                <Route exact
                path="/Login"
                render={() => (this.props.logged? (<Redirect to="/"/>):<Login/>)}
                />
                <Route exact
                path="/Register"
                render={() => (this.props.registered? (<Redirect to="/Login"/>):<Register/>)}
                />
                <Route exact path='/Terms' component={Terms} />
                <Route exact path='/Guarantee' component={Guarantee} />
                <Route exact path='/Policy' component={Policy} />
                <Route exact path='/Locate' component={Locate} />
                <Route exact path='/Contact' component={Contact} />
                {/* <Route exact path='/Register' component={Register} /> */}
                <Route exact
                path="/Profile"
                render={() => (this.props.logged?<Profile />:(<Redirect to="/"/>))}
                />
                <Route exact
                 path='/Profile_edit'
                 render={() =>(this.props.logged && this.props.userData?(this.props.profileUpdate?(<Redirect to="/Profile"/>):<Profile_edit />):(<Redirect to="/"/>))}
                 />
                <Route exact
                path="/Address"
                render={() => (this.props.logged?<Address />:(<Redirect to="/"/>))}
                />
                <Route exact
                 path='/Address_add'
                 render={() =>(this.props.logged ?(this.props.addressAdd?(<Redirect to="/Address"/>):<Address_add />):(<Redirect to="/"/>))}
                 />
                 <Route exact
                 path='/Address_edit/'
                 render={(params) =>(this.props.logged && this.props.userAddress?(this.props.editAddress?(<Redirect to="/Address"/>):<Address_edit id={params}/>):(<Redirect to="/"/>))}
                 />
                 <Route exact path='/view_allproducts' component={All_products} />
                 <Route exact path='/cart' 
                 render={() => (this.props.logged?<Cart />:(<Redirect to="/"/>))}/>
                 <Route exact path='/checkout' 
                 render={() => (this.props.logged?<Checkout />:(<Redirect to="/"/>))}/>
                 <Route exact path='/Orders' 
                 render={() => (this.props.logged?<Orders />:(<Redirect to="/"/>))}/>
                <Route exact
                 path='/payment/'
                 render={(params) =>(this.props.logged ?(<Payment id={params}/>):(<Redirect to="/"/>))}
                 />
                 <Route exact path="/thankyou" component={Thankyou} />
                 <Route exact
                 path='/product_detail/'
                 render={(params) =>(<Product_detail id={params}/>)}
                 />
             </Switch>
             <Footer />
          </div>
       </Router>
    );
 }
}

App.propTypes = {
  applicationRequest: PropTypes.func.isRequired,
  bannerRequest: PropTypes.func.isRequired,
  applicationList:PropTypes.array.isRequired,
  bannerList: PropTypes.array.isRequired,
  logged: PropTypes.bool.isRequired,
  logout: PropTypes.func.isRequired,
  userData: PropTypes.object.isRequired,
  profileUpdate: PropTypes.bool.isRequired,
  userAddress: PropTypes.array.isRequired,
  addressAdd: PropTypes.bool.isRequired,
  editAddress: PropTypes.bool.isRequired,
  registered: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  return {
    applicationList: state.applicationList.get("applicationList"),
    bannerList: state.applicationList.get("bannerList"),
    logged:state.applicationList.get("logged"),
    userData: state.applicationList.get("userData"),
    profileUpdate: state.applicationList.get("profileUpdate"),
    userAddress: state.applicationList.get("userAddress"),
    addressAdd: state.applicationList.get("addressAdd"),
    editAddress: state.applicationList.get("editAddress"),
    registered: state.applicationList.get("registered"),
  };
};

const mapDispatchToProps = dispatch => ({
  applicationRequest: () => dispatch(applicationRequest()),
  bannerRequest: () => dispatch(bannerRequest()),
  logout: () => dispatch(logout()),
  // modalDeleteHandler: application => dispatch(openDeleteModal(application)),
  // deleteModalClose: () => dispatch(closeDeleteModal()),
  // CheckAddModal: (from) => dispatch(openAddModal(from)),
  // closeAddModal: () => dispatch(closeAddModal()),
  // deleteHandler: (id,externalAppId) => dispatch(deleteApplicationRequest(id,externalAppId)),
  // applicationDetail: id => dispatch(applicationDetailRequest(id)),
  // setCreateAppText: (name, androidCode, iosCode) =>
  //   dispatch(setCreateAppText(name, androidCode, iosCode)),
  // createApplication: (id, name, androidCode, iosCode) =>
  //   dispatch(createApplicationRequest(id, name, androidCode, iosCode)),
  //   checkboxEnable:(application)=>dispatch(checkboxEnable(application)),
  //   enableAll:(isEnableAll)=>dispatch(enableAll(isEnableAll)),
  //   editApplication:(externalId,id,name,androidCode,iosCode) =>
  //  dispatch(editApplicationRequest(externalId,id,name,androidCode,iosCode)),
  //  checkboxEnableApplication:(application) =>
  //  dispatch(checkboxEnableApplication(application)),
});

export default connect(mapStateToProps, mapDispatchToProps)(App);
