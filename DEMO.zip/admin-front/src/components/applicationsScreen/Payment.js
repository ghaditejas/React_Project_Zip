import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
  getUserAddress,
  getCart,
  makeOrder,
} from "./actions";

const Loading = ({ paying }) => {
  if (paying) {
    return (
      <div className="text-center">
        <h4>Please do not refresh or press back before completing process</h4>
        <i className="fa fa-circle-o-notch fa-spin" style={{ fontSize: 200 }}></i>
      </div>
    );
  } else {
    return (
      <div className="text-center"></div>
    );
  }
}

class Payment extends Component {
  constructor(props) {
    super(props);
    this.props = props;
    this.state = {
      cvc: "111",
      exp_month: "6",
      exp_year: "22",
      number: "4242424242424242",
      paying: false,
      payment_done: false,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }
  componentWillMount() {
    // this.props.getUserAddress(this.props.id.location.state.addressId, this.props.loginDetails.id, this.props.loginDetails.userId)
    this.props.getCart(this.props.loginDetails.id, this.props.loginDetails.userId)
  }

  componentWillReceiveProps(newProps) {
    if (this.props.placedOrder !== newProps.placedOrder) {
      this.setState({
        payment_done: true,
      });
    }
  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({ [key]: value })
  }

  handleSubmit(event) {
    this.setState({ paying: true, });
    this.props.makeOrder(this.state, this.props.loginDetails.id, this.props.loginDetails.userId, this.props.loginDetails.email, this.props.cartDetails, this.props.id.location.state.addressId);
    event.preventDefault();
  }
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-xs-6 col-md-6 col-md-offset-3">
            <div className="panel panel-default">
              <div className="panel-heading">
                <h3 className="panel-title">Payment Details</h3>
              </div>
              <form>
                <div className="panel-body">
                  <div className="form-group">
                    <label for="cardNumber">CARD NUMBER</label>
                    <div className="input-group">
                      <input className="form-control" id="cardNumber" name="number" value={this.state.number} onChange={this.handleChange} placeholder="Valid Card Number" type="number" />
                    </div>
                    <small className="text-danger">Please enter valid card number</small>
                  </div>
                  <div className="row">
                    <div className="col-xs-7 col-md-7">
                      <label for="expiryMonth">EXPIRY DATE</label>
                      <div className="form-group">
                        <div className="col-xs-6 col-lg-6 pl-ziro">
                          <input className="form-control" id="expiryMonth" name="exp_month" value={this.state.exp_month} onChange={this.handleChange} placeholder="MM" type="number" />
                        </div>
                        <div className="col-xs-6 col-lg-6 pl-ziro">
                          <input className="form-control" id="expityYear" name="exp_year" value={this.state.exp_year} onChange={this.handleChange} placeholder="YY" type="number" />
                        </div>
                      </div>
                    </div>
                    <div className="col-xs-5 col-md-5 pull-right">
                      <div className="form-group">
                        <label for="cvCode">CV CODE</label>
                        <input className="form-control" id="cvCode" name="cvc" value={this.state.cvc} onChange={this.handleChange} placeholder="CV" type="password" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="panel-footer">
                  <br />
                  <button type="submit" className="btn btn-success btn-lg btn-block" onClick={this.handleSubmit} value="Submit Payment">Pay</button>
                  <Loading paying={this.state.paying} />
                  {this.state.payment_done ? <Redirect to="/thankyou" /> : ""}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Payment.propTypes = {
  getUserAddress: PropTypes.func.isRequired,
  loginDetails: PropTypes.object.isRequired,
  placedOrder: PropTypes.bool.isRequired,
};

const mapStateToProps = state => {
  return {
    loginDetails: state.applicationList.get("loginDetails"),
    address: state.applicationList.get("address"),
    cartDetails: state.applicationList.get("cartDetails"),
    placedOrder: state.applicationList.get("placedOrder"),
  };
};

const mapDispatchToProps = dispatch => ({
  // getUserAddress: (addressId, accessToken, userId) => dispatch(getUserAddress(addressId, accessToken, userId)),
  getCart: (accessToken, userId) => dispatch(getCart(accessToken, userId)),
  makeOrder: (card, accessToken, userId, email, product, addressId) => dispatch(makeOrder(card, accessToken, userId, email, product, addressId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Payment);