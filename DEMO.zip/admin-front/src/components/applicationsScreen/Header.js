import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';

const LoggedIn = ({ logout, dropdown }) => {
  return (
    <ul className="dropdown-menu">
      <li onClick={dropdown}><Link to="/Profile"><i className="fa fa-user fa-fw" aria-hidden="true"></i>Profile</Link></li>
      <li onClick={dropdown}><Link to="/Orders"><i className="fa fa-list-alt fa-fw" aria-hidden="true"></i>Orders</Link></li>
      <li onClick={dropdown}><Link to="/Address"><i className="fa fa-address-card-o fa-fw" aria-hidden="true"></i>Addresses</Link></li>
      <li onClick={logout}><Link to="/" onClick={dropdown}><i className="fa fa-sign-out fa-fw" aria-hidden="true"></i>&nbsp; Logout</Link></li>
    </ul>
  );
};

const LoggedOff = ({ dropdown }) => {
  return (
    <ul className="dropdown-menu">
      <li onClick={dropdown}><Link to="/Login"><i className="fa fa-sign-in fa-fw" aria-hidden="true"></i>Login</Link></li>
      <li onClick={dropdown}><Link to="/Register"><i className="fa fa-user-plus fa-fw" aria-hidden="true"></i>Register</Link></li>
    </ul>
  );
};

class Header extends Component {
  constructor(props) {
    super(props);
    this.dropdown = this.dropdown.bind(this);
    this.state = {
      active: false,
    };
  }
  dropdown() {
    const currentState = this.state.active;
    this.setState({ active: !currentState });
  };

  render() {
    return (
      <div>
        <nav className="navbar navbar-default">
          <div className="container">
            <div className="navbar-header">
              <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
                <span className="sr-only">Toggle navigation</span>
                <span className="icon-bar"></span>
                <span className="icon-bar"></span>
                <span className="icon-bar"></span>
              </button>
              <Link to="/" className="navbar-brand">
                <i className="fa fa-shopping-bag fa-lg" aria-hidden="true"> <strong >NeoSTORE</strong> </i>
              </Link>
            </div>
            <div className="collapse navbar-collapse" id="navbar">
              {/* <ul className="nav navbar-nav">
                <li><Link to="/">HOME</Link></li>
              </ul> */}

              {/* <form autoComplete="off" className="pull-left">
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-group">
                      <div className="input-group search-bar">
                        <input name="search" className="form-control" />
                        <span className="input-group-btn">
                          <button type="submit" className="btn btn-default">
                            <i className="fa fa-search"></i>
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </form> */}

              <ul className="nav navbar-nav navbar-right">
                <li className={this.state.active ? 'open' : null}>
                  <a href="#" className="dropdown-toggle" onClick={this.dropdown} data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <i className="fa fa-user fa-lg" area-hidden="true"></i>
                    <span className="caret"></span>
                  </a>
                  {this.props.logged ? <LoggedIn logout={this.props.logout} dropdown={this.dropdown} /> : <LoggedOff dropdown={this.dropdown} />}
                </li>
              </ul>

              <ul className="nav navbar-nav navbar-right">
                <li>
                  <Link className="text-primary" to="/cart">
                    <i className="fa fa-shopping-cart fa-lg" aria-hidden="true"></i>Cart <span className="badge">0</span>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    );
  }
}
export default Header;