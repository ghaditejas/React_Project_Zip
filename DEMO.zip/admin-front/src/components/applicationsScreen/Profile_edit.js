import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
import Textarea from 'react-validation/build/textarea';
import Button from 'react-validation/build/button';
import validator from 'validator';
import {
  applicationRequest,
  bannerRequest,
  loggin,
  getUserData,
  updateUserProfile,
  openDeleteModal,
  closeDeleteModal,
  openAddModal,
  deleteApplicationRequest,
  applicationDetailRequest,
  closeAddModal,
  createApplicationRequest,
  setCreateAppText,
  checkboxEnable,
  editApplicationRequest,
  enableAll,
  checkboxEnableApplication,
} from "./actions";

const required = (value) => {
  if (!value.toString().trim().length) {
    // We can return string or jsx as the 'error' prop for the validated Component
    return(
        <span className="error" style={{color:"red"}}>Require</span>
    );
  }
};

const email = (value) => {
  if (!validator.isEmail(value)) {
    return (
      <span className="error" style={{color:"red"}}>{value} is not a valid email.</span>);
  }
};

class Profile_edit extends Component{
  constructor(props) {
    super(props);
    this.props = props;
    if(this.props.userData.birth_date){
    var date_birth =this.props.userData.birth_date;
    var birth_date = date_birth.split('T')[0];
    }else{
      var birth_date=""
    }
    this.state = {
      first_name: this.props.userData.first_name,
      last_name: this.props.userData.last_name,
      gender: this.props.userData.gender,
      birth_date: birth_date,
      mobile: this.props.userData.mobile,
      email: this.props.userData.email,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const key = target.name;
    this.setState({[key]:value})
  }

  handleSubmit(event) {
    this.props.updateUserProfile(this.state,this.props.loginDetails.id,this.props.loginDetails.userId);
    event.preventDefault();
  }
  render(){
    var  styling = {
          height: "200px",
          width: "200px !important"
        };
    return (
        <div className="container">
    <div className="container">
      <div className="container-fluid">
        <div className="col-md-12">
          <h4> My Account </h4>
          <hr />
        </div>

      <Side_menu /> 
        <div className="col-md-9">
          <div className="panel panel-default">
            <div className="panel-body">
              <h4><strong>Edit Profile</strong></h4>
              <hr />

              <Form>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="firstName">First Name</label>
                      <Input type="text" className="form-control" name ="first_name" onChange={this.handleChange} value={this.state.first_name} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="lastName">Last Name</label>
                      <Input type="text" className="form-control" onChange={this.handleChange} name="last_name"  value={this.state.last_name} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="gender">Gender</label>
                      <div className="checkbox">
                        <label><input type="radio" onChange={this.handleChange} value="male" checked={this.state.gender === "male"} name="gender"/> <strong>Male</strong> </label>
                        <label><input type="radio" onChange={this.handleChange} value="female" checked={this.state.gender === "female"} name="gender" /> <strong>Female</strong> </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="dateOfBirth">Date of Birth</label>
                      <Input type="date" className="form-control" onChange={this.handleChange} name="birth_date" value={this.state.birth_date} placeholder={this.state.birth_date} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="mobile">Mobile</label>
                      <Input type="number" className="form-control" onChange={this.handleChange} name="mobile" value={this.state.mobile} validations={[required]} />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="email">Email</label>
                      <Input type="email" className="form-control" onChange={this.handleChange} name="email" value={this.state.email} validations={[required, email]} />
                    </div>
                  </div>
                </div>

                <hr />
                <Button type="button" onClick={this.handleSubmit} className="btn btn-default btn-lg"><i className="fa fa-floppy-o"></i>Save</Button>
                <Link to="/Profile" type="button" className="btn btn-default btn-lg"><i className="fa fa-remove"></i>Cancel</Link>
              </Form>


            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
      );
  }
}

Profile_edit.propTypes = {
  updateUserProfile: PropTypes.func.isRequired,
  loginDetails: PropTypes.object.isRequired,
  userData: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
 return {
    loginDetails: state.applicationList.get("loginDetails"),
    userData: state.applicationList.get("userData"),
 };
};

const mapDispatchToProps = dispatch => ({
  updateUserProfile: (userProfile,accessToken,userId) => dispatch(updateUserProfile(userProfile,accessToken,userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Profile_edit);