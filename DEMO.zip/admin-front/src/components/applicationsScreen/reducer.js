import ActionTypes from "./actionTypes";
import ApplicationListModel from "./model";
import createReducer from "../../utils/createReducer";
import Notifications, {notify} from 'react-notify-toast';

const applicationListResponse = (state, action) => {
  var logged,loginDetails;
  console.log(localStorage.getItem("login"));
  if(localStorage.getItem("login")){
    logged=true;
    loginDetails=JSON.parse(localStorage.getItem("login"));
    // console.log(JSON.parse(loginDetails));
  } else{
    logged=false;
    loginDetails={};
  }
  return state.set("applicationList", action.payload)
    .set('logged', logged)
    .set('loginDetails',loginDetails);
};

const bannerListResponse = (state, action) =>
  state.set("bannerList", action.payload);

const loginResponse = (state, action) => {
  if (action.payload.id) {
    localStorage.setItem("login",  JSON.stringify(action.payload))
    return state.set('logged', true)
      .set('loginDetails', action.payload);
  }
};

const logoutResponse = (state, action) => {
  localStorage.setItem("login",'')
  return state.set('logged', false)
    .set('loginDetails', {});
};

const userDataResponse = (state, action) => {
  return state.set('userData', action.payload)
    .set('profileUpdate', false);
}

const userAddressResponse = (state, action) => {
  return state.set('userAddress', action.payload)
    .set('addressAdd', false)
    .set('deletedAddress', false)
    .set('editAddress', false);
}

const userPRofileResponse = (state, action) => {
  return state.set('profileUpdate', true)
}

const addUserAddressResponse = (state, action) => {
  return state.set('addressAdd', true);
}

const deleteUserAddressResponse = (state, action) => {
  if (action.payload.count) {
    return state.set('deletedAddress', true);
  }
}

const getAddressResponse = (state, action) => {
  return state.set('address', action.payload)
}

const editAddressResponse = (state, action) => {
  return state.set('editAddress', true);
}

const getAllProducts = (state, action) => {
  return state.set('allProducts', action.payload);
}

const getAllCategories = (state, action) => {
  return state.set('allCategories', action.payload);
}

const getAllColours = (state, action) => {
  return state.set('allColour', action.payload);
}

const addedToCart = (state, action) => {
  return state.set('cartAddMessage', action.payload);
  // .set('cartCount',action.payload);
}

const getCart = (state, action) => {
  return state.set('cartDetails', action.payload)
    .set('cartChange', false)
    .set('placedOrder',false);
}

const removeFromCart = (state, action) => {
  if (action.payload.count)
    return state.set('cartChange', true);
}

const updateCart = (state, action) => {
  return state.set('cartChange', true);
}

const placedOrderStatus = (state,action) => {
  if(action.payload.orderId){
  return state.set('placedOrder',true);
  }
}

const getOrderDetails = (state,action) => {
  if(action.payload.statusCode!==500){
  return state.set('orderDetails',action.payload);
  }else{
    return state.set('orderDetails',[action.payload]);
  }
}

const setProductDetails = (state,action) => {
  return state.set('productDetails',action.payload)
              .set('ratingUpdated',false);
}

const updateProductRatings = (state,action) => {
  return state.set('ratingUpdated',true);
}

const registerResponse = (state,action) => {
  return state.set('registered',true);
}

const contactResponse = (state,action) => {
  if(action.payload="Mail sent successfully"){
  let myColor = { background: '#0E1717', text: "#FFFFFF" };
  notify.show('Mail sent Successfull','success',1000,myColor);
  return state.set('contactMailSend',true);
  }else{
    let myColor = { background: 'RED', text: "#FFFFFF" };
  notify.show('Error occured while sending mail','error',1000,myColor);
  }
}

const applicationDetailResponse = (state, action) => {
  let arr = [];
  action.payload.response.map((item, i) => {
    arr.push({ id: item.id, ischecked: false });
  });
  return state
    .set("checkboxEnableList", arr)
    .set("applicationDetail", action.payload.response)
    .set("requesting", false)
    .set("createApplicationStatus", false);
};

const createApplicationResponse = (state, action) =>
  state.set("createApplication", action.payload).set("requesting", false);

const openDeleteModal = (state, action) =>
  state
    .set("isDeleteModalOpened", true)
    .set("isDeletingApplication", false)
    .set("deletionOk", false)
    .set("deletionError", false)
    .set("selectedApplication", action.payload);

const closeDeleteModal = state => state.set("isDeleteModalOpened", false);

const setCreateAppText = (state, action) => {
  return state
    .set("ApplicationName", action.payload.name)
    .set("applicationAndroidCode", action.payload.androidCode)
    .set("applicationIOSCode", action.payload.iosCode);
};

const openAddModal = (state, action) =>
  state.set("isAddModalOpened", true).set("chkModalFrom", action.payload);

const closeAddModal = (state, action) => {
  if (action.payload === true) {
    return state
      .set("isAddModalOpened", false)
      .set("createApplicationStatus", action.payload)
      .set("isDeletingApplication", false);
  } else {
    return state.set("isAddModalOpened", false);
  }
};

const isDeletingApplication = state => state.set("isDeletingApplication", true);

const deletionOk = state =>
  state
    .set("isDeletingApplication", false)
    .set("deletionError", false)
    .set("deletionOk", true)
    .set("enabledApplication", {})
    .set("ApplicationName", "")
    .set("applicationAndroidCode", "")
    .set("applicationIOSCode", "");

const deletionError = state =>
  state
    .set("isDeletingApplication", false)
    .set("deletionOk", false)
    .set("deletionError", true);

const checkboxEnable = (state, action) =>
  state
    .set("enabledApplication", action.payload)
    .set("ApplicationName", action.payload.name)
    .set("applicationAndroidCode", action.payload.androidCode)
    .set("applicationIOSCode", action.payload.iosCode);

const enableAll = (state, action) => {
  let List = state.get("checkboxEnableList");
  List.map((item, i) => {
    item.ischecked = action.payload;
  });

  return state
    .set("isEnableAll", action.payload)
    .set("checkboxEnableList", List)
    .set("enabledApplication", {})
    .set("ApplicationName", "")
    .set("applicationAndroidCode", "")
    .set("applicationIOSCode", "");
};

const editStatus = (state, action) => {
  let List = state.get("checkboxEnableList");
  List.map((item, i) => {
    item.ischecked = false;
  });

  return state
    .set("checkboxEnableList", List)
    .set("isDeletingApplication", false)
    .set("isAddModalOpened", false)
    .set("editApplicationStatus", action.payload)
    .set("enabledApplication", {})
    .set("ApplicationName", '')
    .set("applicationAndroidCode", '')
    .set("applicationIOSCode", '');
};

const checkboxEnableStatus = (state, action) => {
  let List = state.get("checkboxEnableList");
  List.map((item, i) => {
    if (item.id === action.payload.id) {
      if (item.ischecked === true) {
        item.ischecked = false;
        action.payload = [];
      } else {
        item.ischecked = true;
      }
    } else {
      item.ischecked = false;
    }
  });

  return state
    .set("isEnableAll", false)
    .set("checkboxEnableList", List)
    .set("enabledApplication", action.payload)
    .set("ApplicationName", action.payload.name)
    .set("applicationAndroidCode", action.payload.androidCode)
    .set("applicationIOSCode", action.payload.iosCode);
};

const handlers = {
  [ActionTypes.APPLICATIONLIST_RESPONSE]: applicationListResponse,
  [ActionTypes.BANNERLIST_RESPONSE]: bannerListResponse,
  [ActionTypes.LOGIN_RESPONSE]: loginResponse,
  [ActionTypes.LOGOUT_RESPONSE]: logoutResponse,
  [ActionTypes.USERDATA_RESPONSE]: userDataResponse,
  [ActionTypes.USERADDRESS_RESPONSE]: userAddressResponse,
  [ActionTypes.USERPROFILEUPDATE_RESPONSE]: userPRofileResponse,
  [ActionTypes.ADD_USER_ADDRESS_RESPONSE]: addUserAddressResponse,
  [ActionTypes.DELETE_USER_ADDRESS_RESPONSE]: deleteUserAddressResponse,
  [ActionTypes.GET_ADDRESS_RESPONSE]: getAddressResponse,
  [ActionTypes.EDIT_ADDRESS_RESPONSE]: editAddressResponse,
  [ActionTypes.ALL_PRODUCTS_RESPONSE]: getAllProducts,
  [ActionTypes.ALL_CATEGORIES_RESPONSE]: getAllCategories,
  [ActionTypes.ALL_COLOURS_RESPONSE]: getAllColours,
  [ActionTypes.ADD_TO_CART_RESPONSE]: addedToCart,
  [ActionTypes.CART_DETAILS_RESPONSE]: getCart,
  [ActionTypes.DELETE_CART_PRODUCT_RESPONSE]: removeFromCart,
  [ActionTypes.UPDATE_CART_PRODUCT_RESPONSE]: updateCart,
  [ActionTypes.MAKE_ORDER_RESPONSE]: placedOrderStatus,
  [ActionTypes.GET_ORDER_RESPONSE]: getOrderDetails,
  [ActionTypes.GET_PRODUCT_RESPONSE]: setProductDetails,
  [ActionTypes.UPDATE_RATING_RESPONSE]: updateProductRatings,
  [ActionTypes.REGISTER_RESPONSE]: registerResponse,
  [ActionTypes.CONTACT_RESPONSE]: contactResponse,

  [ActionTypes.APPLICATIONDETAIL_RESPONSE]: applicationDetailResponse,
  [ActionTypes.CREATE_APPLICATION_RESPONSE]: createApplicationResponse,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_OPEN]: openAddModal,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE]: closeAddModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETE_OPEN]: openDeleteModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETE_CLOSE]: closeDeleteModal,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETING]: isDeletingApplication,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETION_OK]: deletionOk,
  [ActionTypes.APPLICATIONLIST_MODAL_DELETION_ERROR]: deletionError,
  [ActionTypes.CREATE_APPLICATION_TEXT]: setCreateAppText,
  [ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX]: checkboxEnable,
  [ActionTypes.APPLICATIONLIST_ENABLE_ALL]: enableAll,
  [ActionTypes.APPLICATIONLIST_MODAL_ADD_CLOSE_EDIT]: editStatus,
  [ActionTypes.APPLICATIONLIST_ENABLE_CHECKBOX_STATUS]: checkboxEnableStatus
};

export default createReducer(handlers, new ApplicationListModel());
