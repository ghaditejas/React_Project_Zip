import { connect } from "react-redux";
import PropTypes from "prop-types";
import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import ReactDOM from 'react-dom';
import Side_menu from './Side_menu';
import {
  applicationRequest,
  bannerRequest,
  loggin,
  getUserData,
  openDeleteModal,
  closeDeleteModal,
  openAddModal,
  deleteApplicationRequest,
  applicationDetailRequest,
  closeAddModal,
  createApplicationRequest,
  setCreateAppText,
  checkboxEnable,
  editApplicationRequest,
  enableAll,
  checkboxEnableApplication,
} from "./actions";

const Date =({date}) => {
  let birth_date=date.split('T')[0];
  return(birth_date);
}

class Profile extends Component{

  componentWillMount(){
    this.props.getUserData(this.props.loginDetails.id,this.props.loginDetails.userId)
  }

  render(){
    var  styling = {
          height: "200px",
          width: "200px !important"
        };
    return (
          <div className="container">
    <div className="container-fluid">
      <div className="col-md-12">
        <h4> My Account </h4>
        <hr />
      </div>

      <Side_menu />

      <div className="col-md-9">
        <div className="panel panel-default">
          <div className="panel-heading">
            <h2>Profile</h2>
            <hr />
          </div>
          <div className="panel-body">
            <table className="table">
              <tbody>
                <tr>
                  <th>First Name</th>
                  <td>{this.props.userData.first_name ? this.props.userData.first_name: ''}</td>
                </tr>
                <tr>
                  <th>Last Name</th>
                  <td>{this.props.userData.last_name ? this.props.userData.last_name: ''}</td>
                </tr>
                <tr>
                  <th>Gender</th>
                  <td>{this.props.userData.gender ? this.props.userData.gender: ''}</td>
                </tr>
                <tr>
                  <th>Date of Birth</th>
                  <td>{this.props.userData.birth_date ? <Date date={this.props.userData.birth_date}/>: ''}</td>
                </tr>
                <tr>
                  <th>Mobile Number</th>
                  <td>{this.props.userData.mobile ? this.props.userData.mobile: ''}</td>
                </tr>
                <tr>
                  <th>Email</th>
                  <td>{this.props.userData.email ? this.props.userData.email: ''}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="panel-footer">
            <hr />
            <Link to="/Profile_edit" type="button" className="btn btn-default btn-lg">Edit</Link>
          </div>
        </div>
      </div>
    </div>
  </div>
      );
  }
}

Profile.propTypes = {
  getUserData: PropTypes.func.isRequired,
 loginDetails: PropTypes.object.isRequired,
 userData: PropTypes.object.isRequired,
};

const mapStateToProps = state => {
 return {
    loginDetails: state.applicationList.get("loginDetails"),
    userData: state.applicationList.get("userData"),
 };
};

const mapDispatchToProps = dispatch => ({
 getUserData: (accessToken,userId) => dispatch(getUserData(accessToken,userId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Profile);