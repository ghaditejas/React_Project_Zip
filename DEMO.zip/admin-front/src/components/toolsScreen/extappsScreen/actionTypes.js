import createActionType from '../../../utils/createActionTypes';

export default createActionType([
  'EXTAPPSLIST_REQUEST',
  'EXTAPPSLIST_RESPONSE',
  'EXTAPPSLIST_ERROR',
]);
