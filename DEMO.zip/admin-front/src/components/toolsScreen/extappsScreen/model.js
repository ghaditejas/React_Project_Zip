import { Record } from 'immutable';

const extApps = Record({
  requesting: true,
  extAppsList: "",
});

export default extApps;
