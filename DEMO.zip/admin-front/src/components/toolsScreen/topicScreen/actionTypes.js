import createActionType from '../../../utils/createActionTypes';

export default createActionType([
  'TOPICLIST_REQUEST',
  'TOPICLIST_RESPONSE',
  'TOPICLIST_ERROR',
]);
