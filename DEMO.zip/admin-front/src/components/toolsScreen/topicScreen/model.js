import { Record } from 'immutable';

const topics = Record({
  requesting: true,
  topicsList: [],
});

export default topics;
